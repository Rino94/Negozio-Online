<?php
//controllo se c'è notifica di modifica
	if (!isset($_GET['ins'])) {
	
// Recupero id prenotazione
	$id=$_GET['id'];
	
//Recupero dati prenotazione
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM prenotazioni_cliente WHERE IDprenotazioneCliente=$id";
	$risultato=mysql_query($query) or die(mysql_error()); 
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
		$IDcliente=$riga['IDcliente'];
		$nome=$riga['Nome'];
		$cognome=$riga['Cognome'];
		$data=$riga['data'];
		$prezzo=$riga['prezzo'];
		$provincia=$riga['Provincia'];
		$citta=$riga['citta'];
		$cap=$riga['cap'];
		$via=$riga['via'];
		$s=$riga['stato'];
		
	if ($s==0) $st="In attesa...";
		else if ($s==1) $st="Evaso";
		else $st="errore";
		
//modifica stato prenotazione	
echo"<form method='get' action='modificaStato.php'";
echo"<br><br>Modifica stato prenotazione: <select name='stato'>";
echo"<option id=0 value=0>In attesa</option>";
echo"<option id=1 value=1>Evaso</option>";
echo"</select>";
echo"<input type='hidden' name='id' value='$id'>";
echo"<input type='submit' value='Conferma cambio stato'><br><br>";
echo"</form>";
	
	echo "<table><tr class='dispari'><td><b>ID Prenotazione</td><td><b>ID Cliente</td><td><b>Nome</td><td><b>Cognome</td><td><b>Data Prenotazione</td><td><b>Prezzo</td><td><b>Provincia</td><td><b>Città</td><td><b>CAP</td><td><b>Via</td><td><b>Stato</td></tr>";
	echo "<tr class='pari'><td>$id</td><td>$IDcliente</td><td>$nome</td><td>$cognome</td><td>$data</td><td>$prezzo</td><td>$provincia</td><td>$citta</td><td>$cap</td><td>$via</td><td> $st </td></tr></table>";
	
	}
	mysql_free_result($risultato);
	mysql_close($cn);
	echo"<br><br><br>";
	echo"<table>";
	echo"<tr class='dispari'><td><b>ID Prodotto:</b></td><td><b>Nome Prodotto:</b></td><td><b>Quantita':</b></td>";
	
	
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM prodotti_prenotazioni_cliente WHERE IDprenotazione=$id";
	$risultato=mysql_query($query);
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
				$IDprodotto=$riga['IDprodotto'];
				$q=$riga['quantita'];

	//Recupero il nome del prodotto
	
	$qq=" SELECT Nome FROM m_prodotti WHERE IDprodotto=$IDprodotto";
	$ris=mysql_query($qq) or die(mysql_error()); 
	while($rig=mysql_fetch_array($ris,MYSQL_ASSOC)){
		foreach($rig as $campo => $valore) 
				$NomeProd=$rig['Nome'];
	} 
				echo"<tr class='pari'><td>$IDprodotto</td><td>$NomeProd</td><td>$q</td></tr>";
	}

	echo"<tr><td><input type='button' value='Elimina prenotazione' onclick=\"location.href='ControlEliminaPrenotazione.php?IDp=$id'\"></center></td></tr>";
	echo"</table>";
mysql_free_result($risultato);
mysql_close($cn);
}
else
echo"Modifica avvenuta correttamente!";	
?>