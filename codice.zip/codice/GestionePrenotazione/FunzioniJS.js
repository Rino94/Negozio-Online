function ControlSel(v) {
	//Data
		if (v==0) {
	var v=new XMLHttpRequest();
	v.onreadystatechange=function() {
	if(v.readyState==4) {
		document.getElementById('tab').innerHTML=v.responseText;
	}
	}
	v.open("GET","OrdinaPerData.php",true);
	v.send(null); 

}

	//In attesa...
if (v==1) {
	var v=new XMLHttpRequest();
	v.onreadystatechange=function() {
	if(v.readyState==4) {
		document.getElementById('tab').innerHTML=v.responseText;
	}
	}
	v.open("GET","CercaInAttesa.php",true);
	v.send(null); 

}
	
	//Evaso
if (v==2) {
	var v=new XMLHttpRequest();
	v.onreadystatechange=function() {
	if(v.readyState==4) {
		document.getElementById('tab').innerHTML=v.responseText;
	}
	}
	v.open("GET","CercaEvaso.php",true);
	v.send(null); 

}
}







