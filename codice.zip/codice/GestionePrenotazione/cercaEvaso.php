<head>
<style type="text/css">
@import "../GestionePersonale/Personale.css";
</style>
</head>
<?php
$i=0;
echo "<table><tr class='dispari'><td>ID Prenotazione</td><td>Nome</td><td>Cognome</td><td>Data</td><td>Stato</td></tr>";

	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM prenotazioni_cliente WHERE stato=1";
	$risultato=mysql_query($query) or die(mysql_error()); 
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
		$IDprenotazione=$riga['idPrenotazioneCliente'];
		$nome=$riga['Nome'];
		$cognome=$riga['Cognome'];
		$data=$riga['data'];
		$s=$riga['stato'];
		$i=1;
		
		if ($s==0) $st="In attesa...";
		else if ($s==1) $st="Evaso";
		else $st="errore";

		echo "<tr class='   pari' id='$IDprenotazione' onclick=\"location.href='TabellaDettagliPrenotazione.php?id=$IDprenotazione'\"> <td> $IDprenotazione </td><td> $nome </td><td> $cognome </td><td> $data </td><td> $st </td></tr>";
	}
	mysql_free_result($risultato);
	mysql_close($cn);

	if ($i==0) echo"<p class='no'><b>Nessuna prenotazione disponibile!!!</b></p>";
?>