<?php session_start(); ?>

<html>
<head>
<title> Gestione Personale </title>

<style type="text/css">
@import "../GestionePersonale/Personale.css";
@import "GestionePrenotazione.css";
</style>

</head>

<body>
<?php
	if(!isset($_SESSION['nik']))	
		echo "Connessione fallita!!!";
	else {
		$n=$_SESSION['nik'];
		
		echo "<div class='contenitore'>";
			 include("../intestazionePersonale.php");
			 echo "<div class='home'> <a href='GestionePrenotazion.php'>-Home </a> </div>";

			 echo "<div class='tabella'>";
				if (isset($_GET['ins'])) {				
						echo"Prenotazione eliminata con successo!!";				
				}
				
			 echo"</div>";
			
		echo "</div>";
	}
?>