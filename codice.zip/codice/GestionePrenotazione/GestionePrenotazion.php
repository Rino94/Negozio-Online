<?php session_start(); ?>

<html>
<!--
CASO D'USO: elencaProdotti
	1.	Il caso d’uso inizia quando il Capo Magazzino è stato autenticato dal sistema e viene reindirizzato alla sua area d’accesso.	
-->
<head>
<title> Gestione Personale </title>

<style type="text/css">
@import "../GestionePersonale/Personale.css";
@import "GestionePrenotazione.css";
</style>
<script type="text/javascript" src="FunzioniJS.js"> </script>
</head>

<body>
<?php
	if(!isset($_SESSION['nik']))	
		echo "Connessione fallita!!!";
	else {
		$n=$_SESSION['nik'];
		echo "<div class='contenitore'>";
			 include("../intestazionePersonale.php");
			echo "<div class='home'> <a href='GestionePrenotazion.php'>-Home </a> </div>";
/*
CASO D'USO: elencaProdotti
	1.	Il caso d’uso inizia quando il Magazziniere è stato autenticato dal sistema e viene reindirizzato alla sua area d’accesso.
2.	Include(ricercaPrenotazioni)
3.	Se il Magazziniere seleziona una determinata prenotazione
<selezionaPrenotazione>


CASO D'USO: ricercaProdotti	
1.	Il Sistema mostra un elenco con non più di dieci prenotazioni unitamente ai criteri di filtraggio.
2.	Se il Magazziniere inserisce i criteri di ricerca:
2.1 Il Sistema ricerca i dati che soddisfano i criteri di ricerca specificati.
2.2 Se il Sistema trova uno o più ordinazioni che soddisfano i criteri:
       2.2.1. Il Sistema mostra un elenco con non più di dieci        ordinazioni.
       2.2.2. Finché ci sono altre ordinazioni
                   2.2.2.1. Il Sistema consente di visualizzare il successivo elenco.

*/
			
			 echo "<div class='sel'>Cerca: <select onchange='ControlSel(this.value)'>";
				echo"<option> in base a: </option>";
				echo"<option value='0'> Data </option>";
				echo"<option value='1'> In attesa... </option>";
				echo"<option value='2'> Evase </option>";

				
			 echo"</select>";
			 echo "</div>";
			 
			 echo "<div class='cerca' id='cerca'> </div>";
			 
			 echo "<div class='tab' id='tab'> </div>";

			
		echo "</div>";
	}
?>