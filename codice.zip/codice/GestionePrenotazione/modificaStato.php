<?php
	$s=$_GET['stato'];
	$id=$_GET['id'];
	
	
	//Modifico lo stato della prenotazione
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline",$cn);
	$query = "UPDATE prenotazioni_cliente SET Stato=$s WHERE idPrenotazioneCliente='$id'";
	mysql_query($query,$cn) or die(mysql_error());
	mysql_close($cn);
	
	header ("location: TabellaDettagliPrenotazione.php?ins=1");	

?>