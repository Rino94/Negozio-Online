<?php
//Prendo i dati
$username=$_POST['username'];
$password=$_POST['password'];

$k=0;
//Accedo al DB e controllo se i dati inseriti dall'attore sono giusti.
$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline");
$query=" SELECT username,password,IDruolo FROM dettaglipersonale";
$risultato=mysql_query($query);
while(($riga=mysql_fetch_array($risultato,MYSQL_ASSOC))&&($k==0)){
	foreach($riga as $campo => $valore)
	if (($riga["username"] == $username) && ($riga["password"] == $password) ) {
		$k=1;
		$r=$riga["IDruolo"];
	}
}
mysql_free_result($risultato);
mysql_close($cn);

//Se dati inseriti sono corretti accedo al DB per estrarre il link a cui devo accedere in base al ruolo dell'attore che ha effettuato il login
if ($k==1) {
	$j=0;
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT IDruolo,link FROM ruolipersonale";
	$risultato=mysql_query($query);
	while(($riga=mysql_fetch_array($risultato,MYSQL_ASSOC))&&($j==0)){
		foreach($riga as $campo => $valore)
		if (($riga["IDruolo"] == $r)) {
			$j=1;
			$l=$riga["link"];
		}
	}
	mysql_free_result($risultato);
	mysql_close($cn);
	
	//apro sessione e reindirizzo
	
	session_start();
	$_SESSION['nik']=$username;
	header("location: $l.php");
}
	else {
	//Se username o password non sono validi, torno alla home e comunico l'errore
	header("location: indexPersonale.php?k=0");
	}