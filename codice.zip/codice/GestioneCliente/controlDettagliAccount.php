<?php
	
	
	
//Recupero id relativo al cliente

	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM cliente WHERE username='$n'";
	$risultato=mysql_query($query) or die(mysql_error()); 
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
		$idC=$riga['IDcliente'];
		$Nome=$riga['Nome'];
		$Cognome=$riga['Cognome'];
		$DataNascita=$riga['DataNascita'];
		$LuogoResidenza=$riga['LuogoResidenza'];
		$Provincia=$riga['Provincia'];
		$CAP=$riga['CAP'];
		$Via=$riga['Via'];
		$Email=$riga['Email'];
//Li stampo in una tabella
	echo"<b>Nome</b>:$Nome<br>";
	echo"<b>Cognome</b>:$Cognome<br>";
	echo"<b>Data di Nascita</b>:$DataNascita<br>";
	echo"<b>Luogo di Residenza</b>:$LuogoResidenza<br>";
	echo"<b>Provincia</b>:$Provincia<br>";
	echo"<b>CAP</b>:$CAP<br>";
	echo"<b>Via</b>:$Via<br>";
	echo"<b>Email</b>:$Email<br>";
	}
	mysql_free_result($risultato);
		
//Cerco le prenotazioni effettuate dal cliente
	$query2=" SELECT * FROM prenotazioni_cliente WHERE IDcliente=$idC";
	$risultato2=mysql_query($query2) or die(mysql_error()); 
	while($riga2=mysql_fetch_array($risultato2,MYSQL_ASSOC)){
		foreach($riga2 as $campo => $valore) 
		$IDprenotazione=$riga2['idPrenotazioneCliente'];
		$Nome2=$riga2['Nome'];
		$Cognome2=$riga2['Cognome'];
		$data=$riga2['data'];
		$prezzo=$riga2['prezzo'];
		$Provincia2=$riga2['Provincia'];
		$citta2=$riga2['citta'];
		$cap2=$riga2['cap'];
		$via2=$riga2['via'];
		$stato=$riga2['stato'];
		
		echo"<table><tr><td><b>ID Prenotazione</td><td><b>Nome</td><td><b>Cognome</td><td><b>Data</td><td><b>Prezzo</td><td><b>Provincia</td><td><b>Città</td><td><b>CAP</td><td>Via<b></td><td>Stato<b></td>";
		echo"<tr><td>$IDprenotazione</td><td>$Nome2</td></td><td>$Cognome2</td><td>$data</td><td>$prezzo</td><td>$Provincia2</td><td>$citta2</td><td>$cap2</td><td>$via2</td><td>$stato</td></tr></table>";
//per ogni prenotazione cerco i rispettivi prodotti in prodotti_prenotazioni_clienti
	$query3=" SELECT * FROM prodotti_prenotazioni_cliente WHERE IDprenotazione=$IDprenotazione";
	$risultato3=mysql_query($query3) or die(mysql_error()); 
	while($riga3=mysql_fetch_array($risultato3,MYSQL_ASSOC)){
	foreach($riga3 as $campo => $valore) 
		$IDprodotto3=$riga3['IDprodotto'];
		$quantita3=$riga3['quantita'];
//per ogni prodotto cerco il suo nome
	$query4=" SELECT * FROM m_prodotti WHERE IDprodotto=$IDprodotto3";
	$risultato4=mysql_query($query4) or die(mysql_error()); 
	while($riga4=mysql_fetch_array($risultato4,MYSQL_ASSOC)){
	foreach($riga4 as $campo => $valore) 
		$Nome4=$riga4['Nome'];
		echo"$Nome4 - $quantita3<br>";	
	}
	mysql_free_result($risultato4);
	}
	mysql_free_result($risultato3);
	}
	mysql_free_result($risultato2);
	
	mysql_close($cn);
	
?>
