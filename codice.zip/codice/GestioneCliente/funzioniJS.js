function evidenziaSottocategoria(id) {
	if (x==0) {//se è la prima categoria che seleziono allora visualizza
		document.getElementById(id+"a").style.display='block';
		document.getElementById(id+"b").style.display='block';
		document.getElementById(id+"c").style.display='block';
	}
	else {//se voglio visualizzare un’altra categoria metto a none quella precedente
		document.getElementById(x+"a").style.display='none';
		document.getElementById(x+"b").style.display='none';
		document.getElementById(x+"c").style.display='none';
		document.getElementById(id+"a").style.display='block';
		document.getElementById(id+"b").style.display='block';
		document.getElementById(id+"c").style.display='block';
	}

x=id;
}

function stampaProdotti(ID) {
	var v=new XMLHttpRequest();
	v.onreadystatechange=function() {
	if(v.readyState==4) {
		document.getElementById('page').innerHTML=v.responseText;
	}
	}
	v.open("GET","tabellaProdotti.php?id="+ID,true);//passo l’id della sottocategoria al server
	v.send(null); 
}

function recuperaPass() {
	document.getElementById('page').innerHTML="Una e-mail e' stata inviata al tuo indirizzo!";
}

function assistenza() {
	document.getElementById('page').innerHTML="Il messaggio e' stato inviato al nostro staff.Cercheremo di risponderti nel piu' breve tempo possibile.Grazie per averci contattato.";
}

function scriviCookie(nomeCookie,valoreCookie,durataCookie)
{
  var scadenza = new Date();
  var adesso = new Date();
  scadenza.setTime(adesso.getTime() + (parseInt(durataCookie) * 60000));
  document.cookie = nomeCookie + '=' + escape(valoreCookie) + '; expires=' + scadenza.toGMTString() + '; path=/';
}

function leggiCookie(nomeCookie)
{
  if (document.cookie.length > 0)
  {
    var inizio = document.cookie.indexOf(nomeCookie + "=");
    if (inizio != -1)
    {
      inizio = inizio + nomeCookie.length + 1;
      var fine = document.cookie.indexOf(";",inizio);
      if (fine == -1) fine = document.cookie.length;
      return unescape(document.cookie.substring(inizio,fine));
    }else{
       return "";
    }
  }
  return "";
}

//CASO D'USO: aggiungiAlCarrello
function settaCOOKIE(idP) {
	if (document.cookie.length > 0) { //se cookie già stato scritto

	COOKIEcarrello=leggiCookie('carr'); //preleva il suo valore
		if ((COOKIEcarrello.lastIndexOf(idP+"abc"))<0) { //se idP non è già stato inserito precedentemente
			COOKIEcarrello=COOKIEcarrello+idP+"abc"; //aggiungi il nuovo id
			scriviCookie('carr',COOKIEcarrello,120); //scrivi cookie
			alert('Prodotto inserito nel carrello');
		}
			else alert('Prodotto gia presente nel carrello');
	} 
	else {
		scriviCookie('carr',idP+"abc",120);
		alert('Prodotto inserito nel carrello');
	}
}

//CASO D'USO: dettagliCarrello
function dettagliCarrello() {
	if ((leggiCookie('carr') == "")||(leggiCookie('carr') == ",")||(leggiCookie('carr') == ",,")) {
		document.getElementById('pg2').innerHTML="Nessun elemento nel carrello";
	}
	else {
		var cookie = leggiCookie('carr');
		var v=new XMLHttpRequest();
		v.onreadystatechange=function() {
		if(v.readyState==4) {
			document.getElementById('pg2').innerHTML=v.responseText;
		}
		}
	v.open("GET","tabellaCarrello.php?cookie="+cookie,true);
	v.send(null); 
	}
}

function svuotaCarrello() {
  scriviCookie('carr','',-1);
  window.location.reload(); //aggiorna pagina
}

function eliminaProdotto(id) {
	cookie=leggiCookie('carr');
	id=id+"abc";
	buff=cookie.split(id);
	b=buff[0]+buff[1];
	scriviCookie('carr',b,120);
	window.location.reload(); //aggiorna pagina
}

function calcolaPrezzo(prezzo,i) {
	if ((document.getElementById('r1').checked == true)||(document.getElementById('r2').checked == true)) 
		document.getElementById('conf').disabled=false;

	if (i==0)
		t=4;
	else
		t=15;
prezzo=prezzo+t;
document.getElementById('prezzo').innerHTML="Prezzo TOTALE:"+prezzo;
document.getElementById('prez').value=prezzo;
																
}

function confermaAcquisto() {
		alert("Devi selezionare un metodo di pagamento!!!");	
}

//CONTROLLI INPUT ---------------------------------------------------------------
function controlloTesto(testo,id){
	var patt = /^([a-zA-Z\xE0\xE8\xE9\xF9\xF2\xEC\x27]\s?)+$/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById(id).innerHTML="<p class='vero'><b>OK</b></p>";
			return true;
		}
		else {
			document.getElementById(id).innerHTML="<p class='falso'><b>errore</b></p>";
			return false;
			}
}

function controlloTest(testo,id){
	var patt = /^([a-zA-Z\xE0\xE8\xE9\xF9\xF2\xEC\x27]\s?){4,30}$/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById(id).innerHTML="<p class='vero'><b>OK</b></p>";
			return true;
		}
		else {
			document.getElementById(id).innerHTML="<p class='falso'><b>errore</b></p>";
			return false;
			}
}

function controlloPro(testo,id){
	var patt = /^([a-zA-Z\xE0\xE8\xE9\xF9\xF2\xEC\x27]\s?){2}$/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById(id).innerHTML="<p class='vero'><b>OK</b></p>";
			return true;
		}
		else {
			document.getElementById(id).innerHTML="<p class='falso'><b>errore</b></p>";
			return false;
			}
}

function controlloChar(testo,id){
	var patt = /^([a-zA-Z0-9\.\_\-])+$/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById(id).innerHTML="<p class='vero'><b>OK</b></p>";
			return true;
		}
		else {
			document.getElementById(id).innerHTML="<p class='falso'><b>errore</b></p>";
			return false;
		}
}

function controlloPass(testo,id){
	var patt = /^[a-zA-Z0-9\_\*\-\+\!\?\.\xE0\xE8\xE9\xF9\xF2\xEC\x27]{6,12}/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById(id).innerHTML="<p class='vero'><b>OK</b></p>";
			return true;
		}
		else {
			document.getElementById(id).innerHTML="<p class='falso'><b>errore</b></p>";
			return false;
		}
}

function controlloRpass(p1,id){
		p2=document.getElementById('p1');
		p2=p2.value;
		if (p1==p2) {
			document.getElementById(id).innerHTML="<p class='vero'><b>OK</b></p>";
			return true;
		}
		else {
			document.getElementById(id).innerHTML="<p class='falso'><b>errore</b></p>";
			return false;
		}
}


function controlloData(testo,id){
	var patt = /^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[-/.](19|20)\d\d/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById(id).innerHTML="<p class='vero'><b>OK</b></p>";
			return true;
		}
		else {
			document.getElementById(id).innerHTML="<p class='falso'><b>errore</b></p>";
			return false;
		}
}


function controlloCAP(testo,id){
	var patt = /^\d{5}$/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById(id).innerHTML="<p class='vero'><b>OK</b></p>";
			return true;
		}
		else {
			document.getElementById(id).innerHTML="<p class='falso'><b>errore</b></p>";
			return false;
		}
}

function controlloEmail(testo,id){
	var patt = /^[a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById(id).innerHTML="<p class='vero'><b>OK</b></p>";
			return true;
		}
		else {
			document.getElementById(id).innerHTML="<p class='falso'><b>errore</b></p>";
			return false;
		}
}



function controlloNum(testo,id){
	var patt = /^\d+$/; 
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById(id).innerHTML="<p class='vero'><b>OK</b></p>";
			return true;
		}
		else {
			document.getElementById(id).innerHTML="<p class='falso'><b>errore</b></p>";
			return false;
		}
}

function controlloVia(testo,id){
	
			document.getElementById(id).innerHTML="<p class='vero'><b>OK</b></p>";
			return true;
		
}

function controllaIscrizione() {
	aa=document.getElementById('aa').value;
	a=controlloTest(aa,'a');
	bb=document.getElementById('bb').value;
	b=controlloTest(bb,'b');
	cc=document.getElementById('cc').value;
	c=controlloChar(cc,'c');
	p1=document.getElementById('p1').value;
	d=controlloPass(p1,'d');
	ee=document.getElementById('ee').value;
	e=controlloRpass(ee,'e');
	ff=document.getElementById('ff').value;
	f=controlloData(ff,'f');
	gg=document.getElementById('gg').value;
	g=controlloTest(gg,'g');
	hh=document.getElementById('hh').value;
	h=controlloTest(hh,'h');
	ii=document.getElementById('ii').value;
	i=controlloCAP(ii,'i');
	ll=document.getElementById('ll').value;
	l=controlloPro(ll,'l');
	mm=document.getElementById('mm').value;
	m=controlloVia(mm,'m');
	nn=document.getElementById('nn').value;
	n=controlloEmail(nn,'n');

	
	
	if ((a==false)||(b==false)||(c==false)||(d==false)||(e==false)||(f==false)||(g==false)||(h==false)||(i==false)||(l==false)||(m==false)||(n==false)) {
		
			alert("Errore nella compilazione campi");
			return false; 
			} 
			else
	return true;
}


function controllaModifica() {
	aa=document.getElementById('aa').value;
	a=controlloTest(aa,'a');
	bb=document.getElementById('bb').value;
	b=controlloTest(bb,'b');
	cc=document.getElementById('cc').value;
	c=controlloChar(cc,'c');
	ff=document.getElementById('ff').value;
	f=controlloData(ff,'f');
	gg=document.getElementById('gg').value;
	g=controlloTest(gg,'g');
	ll=document.getElementById('ll').value;
	l=controlloPro(ll,'l');
	ii=document.getElementById('ii').value;
	i=controlloCAP(ii,'i');
	mm=document.getElementById('mm').value;
	m=controlloVia(mm,'m');
	nn=document.getElementById('nn').value;
	n=controlloEmail(nn,'n');

	
	
	if ((a==false)||(b==false)||(c==false)||(f==false)||(g==false)||(l==false)||(i==false)||(m==false)||(n==false)) {
		
			alert("Errore nella compilazione campi");
			return false; 
			} 
			else
	return true;
}




function controllaGiac(att,max) {

if(att>max){
	alert("Quantita troppo elevata");
	return false;
}
	else
return true;

}