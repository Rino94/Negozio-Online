<?php
/*
CASO D'USO:confermaAcquisto
1.	Il sistema mostra un riepilogo sui prodotti che il cliente sta acquistando e sulle informazioni inserite precedentemente.
2.	Se il cliente vuole procedere nell’acquisto clicca su “Conferma Acquisto”.
3.	Il Cliente viene affidato ad un sistema esterno (Gateway di pagamento) per effettuare il pagamento.
4.	Se il Cliente effettua il pagamento, il sistema viene aggiornato.

*/
	//Recupero dati carrello
		$id = $_GET['idd'];
		$q=$_GET['qua'];
		$n=count($id);
	
	//Recupero dati cliente
	$IDcliente=$_GET['IDcliente'];
	$nomeC=$_GET['nome'];
	$cognome=$_GET['cognome'];
	$citta=$_GET['citta'];
	$prov=$_GET['prov'];
	$CAP=$_GET['CAP'];
	$via=$_GET['via'];
	
	echo"<b>Indirizzo per la consegna:</b><br>";
	echo"$nomeC $cognome<br>";
	echo"$citta $prov<br>";
	echo"$CAP $via<br>";
	
	echo"<b>Carrello:</b>";
	$tot=0;
	//Recupero dati del prodotto
	for($i=0;$i<$n;$i++) {
		$idProdotto=$id[$i];
		$quantitaOrd=$q[$i];
		
		
		echo"<table>";
		echo"<form method='post' action='pagamento.php'";
		//Accedo al DB
		$cn = mysql_connect("localhost","root");
		mysql_select_db("negozionline");
		$query=" SELECT * FROM m_prodotti WHERE IDprodotto=$idProdotto";
		$risultato=mysql_query($query) or die(mysql_error()); 
		while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
			foreach($riga as $campo => $valore) 
			$nomeP=$riga['Nome'];
			$p=$riga['Prezzo'];
			$imm=$riga['Immagine'];
			$tot=$tot+($p*$quantitaOrd);
			echo"<tr><td><imm src='../gestioneMagazzino/$imm' width=100px></td><td>$nomeP</td><td>Quantita': $quantitaOrd</td><td>Prezzo: $p x $quantitaOrd</td></tr>";
		}
		echo"</table>";
	}
	mysql_free_result($risultato);
	mysql_close($cn);
	//Scelgo tipo di spedizione
	
	echo"<table><tr><td colspan=2><br><b>Scegli l'opzione di spedizione desiderata:</b></td></tr>";
	echo"<tr><td ><input type='radio' id='r1' name='sped' onclick='calcolaPrezzo($tot,0)'></td><td><u>Spedizione standard</u><br>Tassa di Spedizione: 4 EURO<br><br></td></tr>";
	echo"<tr><td ><input type='radio' id='r2' name='sped' onclick='calcolaPrezzo($tot,1)'></td><td><u>Spedizione Espressa</u><br>Tassa di Spedizione: 15 EURO<br>Vantaggi:<br>-consegna piu veloce<br>-assicurazione della merce</td></tr>";
	echo"</table>";
	
	
	echo"<span id='prezzo'>Prezzo TOTALE: $tot</span>";
	
	//conferma acquisto
	echo"<br><input type='submit' value='Conferma Acquisto' id='conf' disabled='disabled'>";

	
	//passaggio valori per pagamento	
	//prezzo
	echo"<input type='hidden' name='prezzo' id='prez'>";


		//dettagli cliente
		echo"<input type='hidden' name='nome' value='$nomeC'>";
		echo"<input type='hidden' name='cognome' value='$cognome'>";
		echo"<input type='hidden' name='citta' value='$citta'>";
		echo"<input type='hidden' name='prov' value='$prov'>";
		echo"<input type='hidden' name='CAP' value='$CAP'>";
		echo"<input type='hidden' name='via' value='$via'>";
		echo"<input type='hidden' name='IDcliente' value='$IDcliente'>";
		
		//prodotti e quantita
		for($i=0;$i<$n;$i++) {
		$aa=$id[$i];
		$bb=$q[$i];
		echo"<input type='hidden' name='idd[]' value='$aa'>";
		echo"<input type='hidden' name='qua[]' value='$bb'>";
	}
	
	echo"</form>";

?>