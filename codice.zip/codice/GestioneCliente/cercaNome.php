<?php
/*
CASO D'USO:ricercaProdotti
1.	Il Sistema mostra un elenco di prodotti unitamente ai criteri di filtraggio.
2.	Se il Cliente inserisce i criteri di ricerca:
2.1 Il Sistema ricerca i dati che soddisfano i criteri di ricerca specificati.
2.2 Se il Sistema trova uno o più prodotti che soddisfano i criteri:
       2.2.1. Il Sistema mostra un elenco di  prodotti.
       2.2.2. Finché ci sono altre prodotti
                   2.2.2.1. Il Sistema consente di visualizzare il successivo elenco.

*/
//Recupero ID della sottocategoria per la quale devo stampare i prodotti
	$nome=$_GET['nome'];
	$ii=0;
	
	
//Accedo al m_prodotti e per ogni IDs==$IDs stampo tabella (devo recuperare anche quantita in p_prodotti)
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM m_prodotti WHERE Nome='$nome'";
	$risultato=mysql_query($query) or die(mysql_error()); 
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
		$ii=1;
		$idP=$riga['IDprodotto'];
		$n=$riga['Nome'];
		$d=$riga['Descrizione'];
		$st=$riga['Scheda_Tecnica'];
		$p=$riga['Prezzo'];
		$i=$riga['Immagine'];
		$g=$riga['Giacenza'];
		
		
//Controllo in p_prodotti se ci sono prodotti in arrivo
	$tot=0;
	$query2=" SELECT * FROM p_prodotti WHERE IDprodotto=$idP";
	$risultato2=mysql_query($query2) or die(mysql_error()); 
	while($riga2=mysql_fetch_array($risultato2,MYSQL_ASSOC)){
		foreach($riga2 as $campo => $valore) 
		$q=$riga2['quantita'];
		$tot=$tot+$q;
	}
	mysql_free_result($risultato2);

if ($ii==1)	{
//Creo Tabella
echo "<table>";
echo "<tr><td colspan='2' class='nomeTab'>$n</td></tr>";
echo "<tr><td colspan='2' class='codTab'>Cod: $idP - Disponibilit': $g - In arrivo: $tot</td></tr>";
echo "<tr><td rowspan='2'> <img src='../GestioneMagazzino/immProdotti/$i' width=200px> </td><td><b>Scheda Tecnica:</b><br>$st</td></tr>";
echo "<tr><td class='prezzo'>PREZZO: <b>$p &euro;</b> </td></tr>";
echo "<tr><td colspan='2' class='carr'> AGGIUNGI AL CARRELLO </td></tr>";
echo "<tr><td colspan='2'><br><b> DESCRIZIONE:<br> </b><br> $d </td></tr></table>";
}
		
	}
	mysql_free_result($risultato);
	mysql_close($cn);
	
if ($ii==0)
		echo"<table><tr><td>Nessun prodotto trovato per: <b>'$nome'</b> </td></tr></table>";

	
?>