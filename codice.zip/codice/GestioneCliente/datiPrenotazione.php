<?php
if(isset($_SESSION['nick']))	{
	$n=$_SESSION['nick'];
/*
1.	Il Cliente compila i form contenente le informazione per la spedizione e il pagamento dei prodotti.
2.	Il Cliente clicca su “Conferma Acquisto”
*/
	if(isset($_SESSION['nick']))	
		$n=$_SESSION['nick'];
//recupero idP e quant
	$ID=$_GET['idProd'];
	$qq=$_GET['quant'];
	
	$nn=count($ID);
	
//accedo a DB e recupero dati cliente
	    $cn = mysql_connect("localhost","root");
		mysql_select_db("negozionline");
		$query=" SELECT * FROM cliente WHERE Username='$n'";
		$risultato=mysql_query($query) or die(mysql_error()); 
		while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
			foreach($riga as $campo => $valore) 
			$IDcliente=$riga['IDcliente'];
			$Cognome=$riga['Cognome'];
			$Nome=$riga['Nome'];
			$citta=$riga['LuogoResidenza'];
			$prov=$riga['Provincia'];
			$CAP=$riga['CAP'];
			$via=$riga['Via'];
			
		}
//METODO 1
	echo"<form method='GET' action='confermaAcquisto.php'>";
	echo"<table>";
	echo"<tr><td><input type='submit' value='utilizza questo indirizzo1'></td></tr>";
	echo"<tr><td><b>$Nome $Cognome</b></td></tr>";
	echo"<tr><td>$via</td></tr>";
	echo"<tr><td>$CAP $citta</td></tr>";
	echo"<tr><td>$prov</td></tr>";
	echo"<input type='hidden' name='IDcliente' value='$IDcliente'>";
	
	for($i=0;$i<$nn;$i++) {
		$aa=$ID[$i];
		$bb=$qq[$i];
		echo"<input type='hidden' name='idd[]' value='$aa'>";
		echo"<input type='hidden' name='qua[]' value='$bb'>";
	}
		
		echo"<input type='hidden' name='nome' value='$Nome'>";
		echo"<input type='hidden' name='cognome' value='$Cognome'>";
		echo"<input type='hidden' name='citta' value='$citta'>";
		echo"<input type='hidden' name='prov' value='$prov'>";
		echo"<input type='hidden' name='CAP' value='$CAP'>";
		echo"<input type='hidden' name='via' value='$via'>";
	
	echo"</form>";
	echo"</table>";
//METODO 2	
	echo"<form method='get' action='confermaAcquisto.php'>";

	echo"<table>";
	echo"<tr><td colspan='2'><input type='submit' value='utilizza questo indirizzo'></td></tr>";
	echo"<tr><td>Nome:</td><td><input type='text' name='nome'></td></tr>";
	echo"<tr><td>Cognome:</td><td><input type='text' name='cognome'></td></tr>";
	echo"<tr><td>Citta:</td><td><input type='text' name='citta'></td></tr>";
	echo"<tr><td>Provincia:</td><td><input type='text' name='prov'></td></tr>";
	echo"<tr><td>Cap:</td><td><input type='text' name='CAP'></td></tr>";
	echo"<tr><td>Via:</td><td><input type='text' name='via'></td></tr>";
	
	for($i=0;$i<$nn;$i++) {
		$aa=$ID[$i];
		$bb=$qq[$i];
		echo"<input type='hidden' name='idd[]' value='$aa'>";
		echo"<input type='hidden' name='qua[]' value='$bb'>";
	}
	echo"<input type='hidden' name='IDcliente' value='$IDcliente'>";
	
	echo"</form>";
	echo"</table>";
	
	mysql_free_result($risultato);
	mysql_close($cn);
}
else
	echo"effettuare il login per procedere";
?>