<?php
session_start();
$n=$_SESSION['nick'];

//Recupero i dati
				$Nome=$_POST['nome'];
				$Cognome=$_POST['cognome'];
				$DataNascita=$_POST['DataNascita'];
				$LuogoResidenza=$_POST['LuogoResidenza'];
				$Provincia=$_POST['Provincia'];
				$CAP=$_POST['CAP'];
				$Via=$_POST['Via'];
				$Email=$_POST['Email'];;

//Accedo al DB e modifico i dati.
$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline",$cn);
$query = "UPDATE cliente SET Nome='$Nome',Cognome='$Cognome',DataNascita='$DataNascita',LuogoResidenza='$LuogoResidenza',Provincia='$Provincia',CAP='$CAP',Via='$Via',Email='$Email' WHERE Username='$n'";
mysql_query($query,$cn) or die(mysql_error());
mysql_close($cn);

//Torno alla pagina di inserimento e notifico l'avvenuto inserimento
header ("location: modificaAccount.php?ins=1");	

	?>