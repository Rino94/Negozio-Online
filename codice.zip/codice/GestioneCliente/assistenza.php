<?php session_start(); ?>
<html>
<head>
<title>Negozio Online </title>
<style type="text/css">
@import "GestioneCliente.css";
</style>
<script type="text/javascript" src="funzioniJS.js"> </script>
<script type="text/javascript"> x=0; </script>
</head>
<body>
<!--controllo se c'è una sessione attiva -->
<?php
if(isset($_SESSION['nick']))	
	$n=$_SESSION['nick'];
?>

<form method='get' action='cercaNomeProdotto.php'> <!-- form per ricerca prodotto -->
<div id='contenitore'>
		
	<div id='intestazione'> <img src='../image/logo.jpg' height=75px> <a class='c' href='index.php'><span class='a'>NEGOZI<b>O</b></span><span class='b'>NLINE</span></a> 
		<div class='ric'> <input type='text' name='nome'><input type='submit' value='cerca'></form><br>
		<?php if(isset($n)) echo "Salve, $n";
		?></div>
	</div>


	<div id='centro'>

		<div id='menu'> <?php include("menu.php");?> </div>

		<div id='info'> <?php include("areaCliente.php");?> </div>
		
		<div id='page'>
<!--
CASO D'USO:chiediAssistenza
1.	Il cliente compila il form e seleziona “Invia Richiesta”
2.	Finché si verificano errori durante l’inserimento dei dati
2.1. Il Sistema visualizza un messaggio che descrive lo scenario.
2.2. Il Sistema consente il Cliente di correggere l’errore.
2.3. Il Cliente modifica tutti o parte dei dati.
2.4. Il Cliente avvia la registrazione dei dati, facendo clic sul pulsante “Invia Richiesta”.
Altrimenti:
3.  Il Sistema conferma l’avvenuto invio.


-->
				<table><tr>
				<td>Username: </td>
				<?php echo"<td> <input type='text' onkeyup='controlloChar(this.value,\"a\")'> </td>"; ?>
				<td id='a'></td></tr>
				<tr><td>Email: </td><td> <input type='text' <?php echo"onkeyup='controlloEmail(this.value,\"b\")'"; ?>> </td><td id='b'></td></tr>
				<tr><td>Oggetto: </td><td> <input type='text' <?php echo"onkeyup='controlloVia(this.value,\"c\")'"; ?>> </td><td id='c'></td></tr>
				<tr><td>Messaggio: </td><td> <textarea cols='50' rows='10' <?php echo"onkeyup='controlloVia(this.value,\"d\")'"; ?>> </textarea> </td><td id='d'></td></tr>
				<tr><td><input type='button' value='Invia' onclick='assistenza()'> </td><td id='e'></td></tr>
		</table>
		</div>
			
	</div>
	
	<div id='footer'>  </div>
	
	
</div> 

</body>
</html>