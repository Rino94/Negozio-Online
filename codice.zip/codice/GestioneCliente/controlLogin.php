<?php
/*
CASO D'USO: effettuaLogin
2.	Il Sistema memorizza i dati appena inseriti.
3.	Finché si verificano errori durante l’inserimento dei dati
3.1. Il Sistema visualizza un messaggio che descrive lo scenario.
3.2. Il Sistema consente al Cliente di correggere l’errore.
3.3. Il Cliente modifica tutti o parte dei dati.
3.4. Il Cliente avvia la registrazione dei dati, facendo clic sul pulsante “Login”.
4.	Altrimenti:
4.1.  Il Cliente viene autenticato dal sistema.


*/
//Prendo i dati
$username=$_POST['username'];
$password=$_POST['password'];

$k=0;
//Accedo al DB e controllo se i dati inseriti sono giusti.
$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline");
$query=" SELECT username,password FROM cliente";
$risultato=mysql_query($query);
while(($riga=mysql_fetch_array($risultato,MYSQL_ASSOC))&&($k==0)){
	foreach($riga as $campo => $valore)
	if (($riga["username"] == $username) && ($riga["password"] == $password) ) {
		$k=1;
	}
}
mysql_free_result($risultato);
mysql_close($cn);

//Se dati inseriti sono corretti creo la sessione
if ($k==1) {
	
	session_start();
	$_SESSION['nick']=$username;
	header("location: index.php");
}
	else {
	//Se username o password non sono validi comunico errore
	header("location: login.php?k=0");
	}