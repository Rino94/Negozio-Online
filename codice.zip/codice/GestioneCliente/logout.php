<?php
session_start();
$_SESSION['nick'] = array();
session_destroy();
header('location: index.php');
exit();
?>