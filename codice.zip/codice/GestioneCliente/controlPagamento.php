<?php
	//recupero valori
	$prezzo=$_POST['prezzo'];
	
	//dati cliente
	$IDcliente=$_POST['IDcliente'];
	$nomeC=$_POST['nome'];
	$cognome=$_POST['cognome'];
	$citta=$_POST['citta'];
	$prov=$_POST['prov'];
	$CAP=$_POST['CAP'];
	$via=$_POST['via'];
	
	//prodotti
		$id = $_POST['idd'];
		$qq=$_POST['qua'];
		$n=count($id);
		
//inserisco record in DB prenotazioni_cliente
	$data=date("d-m-y");
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline",$cn);
	$query = "INSERT INTO prenotazioni_cliente (IDcliente,stato,data,prezzo,citta,cap,via,Nome,Cognome,Provincia)  VALUES ('$IDcliente',0,'$data','$prezzo','$citta','$CAP','$via','$nomeC','$cognome','$prov')"; 
	mysql_query($query,$cn) or die(mysql_error());
	$IDpren=mysql_insert_id();
	mysql_close($cn);
	
//per ogni prodotto ordinato:
for ($i=0;$i<$n;$i++) {
	$q=$qq[$i];
	$idP=$id[$i];
	//-modifico DB m_prodotti decrementando giacenza
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline",$cn);
	$query = "UPDATE m_prodotti SET Giacenza=Giacenza-$q WHERE IDprodotto='$idP'";
	mysql_query($query,$cn) or die(mysql_error());
	
	mysql_select_db("negozionline",$cn);
	$query = "INSERT INTO prodotti_prenotazioni_cliente (IDprodotto,IDprenotazione,quantita)  VALUES ('$idP','$IDpren','$q')"; 
	
	
	
	mysql_query($query,$cn) or die(mysql_error());
	mysql_close($cn);
}

header("location: index.php?ins=1");

?>