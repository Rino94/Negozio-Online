<?php
/*
CASO D'USO: effettuaIscrizione
1.	Il Cliente inserisce i dati e conferma l’inserimento selezionando “conferma”.
2.	Il Sistema memorizza i dati appena inseriti.
3.	Finché si verificano errori durante l’inserimento dei dati
3.1. Il Sistema visualizza un messaggio che descrive lo scenario.
3.2. Il Sistema consente al Cliente di correggere l’errore.
3.3. Il Cliente modifica tutti o parte dei dati.
3.4. Il Cliente avvia la registrazione dei dati, facendo clic sul pulsante “conferma”.
4.	Altrimenti:
4.1. Il Sistema conferma l’avvenuto inserimento.

*/
	echo"<form method='post' action='confermaIscrizione.php' onsubmit='return controllaIscrizione()'>";
	echo"<table>";
	echo"<tr><td colspan='2'> Registrazione </td></tr>";
	echo"<tr><td>Nome: </td><td><input type='text' name='nome' id='aa' onkeyup='controlloTest(this.value,\"a\")'></td><td id='a'></td></tr>";
	echo"<tr><td>Cognome: </td><td><input type='text' name='cognome' id='bb' onkeyup='controlloTest(this.value,\"b\")'></td><td id='b'></td></tr>";
	echo"<tr><td>Username: </td><td><input type='text' name='username' id='cc' onkeyup='controlloChar(this.value,\"c\")'></td><td id='c'></td></tr>";
	echo"<tr><td>Password: </td><td><input type='password' id='p1' name='password' onkeyup='controlloPass(this.value,\"d\")'></td><td id='d'></td></tr>";
	echo"<tr><td>Ripeti Password: </td><td><input type='password' name='Rpassword' id='ee' onkeyup='controlloRpass(this.value,\"e\")'></td><td id='e'></td></tr>";
	echo"<tr><td>Data di nascita: </td><td><input type='text' name='datan' id='ff' onkeyup='controlloData(this.value,\"f\")' maxlength='10' size=10></td><td id='f'></td></tr>";
	echo"<tr><td>Luogo di Nascita: </td><td><input type='text' name='luogon' id='gg' onkeyup='controlloTest(this.value,\"g\")'></td><td id='g'></td></tr>";
	echo"<tr><td>Residente a: </td><td><input type='text' name='residenza' id='hh' onkeyup='controlloTest(this.value,\"h\")'></td><td id='h'></td></tr>";
	echo"<tr><td>CAP: </td><td><input type='text' name='cap' id='ii' onkeyup='controlloCAP(this.value,\"i\")' maxlength='5' size=5></td><td id='i'></td></tr>";
	echo"<tr><td>Provincia: </td><td><input type='text' name='prov' id='ll' onkeyup='controlloPro(this.value,\"l\")' maxlength='2' size=2></td><td id='l'></td></tr>";
	echo"<tr><td>Via: </td><td><input type='text' name='via' id='mm' onkeyup='controlloVia(this.value,\"m\")'></td><td id='m'></td></tr>";
	echo"<tr><td>Email: </td><td><input type='text' name='email' id='nn' onkeyup='controlloEmail(this.value,\"n\")'></td><td id='n'></td></tr>";
	echo"<tr><td colspan='2'> <input type='submit' value='Conferma'>  </td><td id='p'></td></tr>";
	echo"</table></form>";
	?>