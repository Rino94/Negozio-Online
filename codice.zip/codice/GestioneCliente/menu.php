<?php
/*
CASO D'USO:elencaProdotti
1.	Il caso d’uso inizia quando il Cliente seleziona una voce del menù per vedere i vari prodotti o quando effettua una specifica ricerca utilizzando il form corrispondente.
2.	Include(ricercaProdotti)
3.	Se il Cliente seleziona un prodotto
<selezionaProdotti>


*/

echo"<p class='categoria' id=1 onclick='evidenziaSottocategoria(this.id)'>Audio</p>";
echo"<p class='sottocategoria' id=1a style='display:none' onclick='stampaProdotti(1)'> - Amplificatori </p>";
echo"<p class='sottocategoria' id=1b style='display:none' onclick='stampaProdotti(2)'> - Home cinema </p>";
echo"<p class='sottocategoria' id=1c style='display:none' onclick='stampaProdotti(3)'> - Lettori mp3/mp4 </p>";

echo"<p class='categoria' id=2 onclick='evidenziaSottocategoria(this.id)'>Desktop e Notebook</p>";
echo"<p class='sottocategoria' id=2a style='display:none' onclick='stampaProdotti(4)'> - Notebook </p>";
echo"<p class='sottocategoria' id=2b style='display:none' onclick='stampaProdotti(5)'> - Pc </p>";
echo"<p class='sottocategoria' id=2c style='display:none' onclick='stampaProdotti(6)'> - PC-accessori </p>";

echo"<p class='categoria' id=3 onclick='evidenziaSottocategoria(this.id)'>Elettrodomestici Grandi</p>";
echo"<p class='sottocategoria' id=3a style='display:none' onclick='stampaProdotti(7)'> - Frigoriferi </p>";
echo"<p class='sottocategoria' id=3b style='display:none' onclick='stampaProdotti(8)'> - Lavastoviglie </p>";
echo"<p class='sottocategoria' id=3c style='display:none' onclick='stampaProdotti(9)'> - Lavatrici </p>";

echo"<p class='categoria' id=4 onclick='evidenziaSottocategoria(this.id)'>Elettrodomestici Piccoli</p>";
echo"<p class='sottocategoria' id=4a style='display:none' onclick='stampaProdotti(10)'> - Cottura </p>";
echo"<p class='sottocategoria' id=4b style='display:none' onclick='stampaProdotti(11)'> - Forni a microonde </p>";
echo"<p class='sottocategoria' id=4c style='display:none' onclick='stampaProdotti(12)'> - Macchine da caffè </p>";

echo"<p class='categoria' id=5 onclick='evidenziaSottocategoria(this.id)'>Fotografia</p>";
echo"<p class='sottocategoria' id=5a style='display:none' onclick='stampaProdotti(13)'> - Reflex </p>";
echo"<p class='sottocategoria' id=5b style='display:none' onclick='stampaProdotti(14)'> - Obiettivi </p>";
echo"<p class='sottocategoria' id=5c style='display:none' onclick='stampaProdotti(15)'> - Accessori foto/video </p>";

echo"<p class='categoria' id=6 onclick='evidenziaSottocategoria(this.id)'>Giochi</p>";
echo"<p class='sottocategoria' id=6a style='display:none' onclick='stampaProdotti(16)'> - Consoles games </p>";
echo"<p class='sottocategoria' id=6b style='display:none' onclick='stampaProdotti(17)'> - Controlles </p>";
echo"<p class='sottocategoria' id=6c style='display:none' onclick='stampaProdotti(18)'> - Videogames </p>";

echo"<p class='categoria' id=7 onclick='evidenziaSottocategoria(this.id)'>Monitor e Periferiche</p>";
echo"<p class='sottocategoria' id=7a style='display:none' onclick='stampaProdotti(20)'> - Monitor LCD </p>";
echo"<p class='sottocategoria' id=7b style='display:none' onclick='stampaProdotti(21)'> - Tastiere e Mouse </p>";
echo"<p class='sottocategoria' id=7c style='display:none' onclick='stampaProdotti(22)'> - Web-cam </p>";

echo"<p class='categoria' id=8 onclick='evidenziaSottocategoria(this.id)'>Network e Wireless</p>";
echo"<p class='sottocategoria' id=8a style='display:none' onclick='stampaProdotti(23)'> - Firewall </p>";
echo"<p class='sottocategoria' id=8b style='display:none' onclick='stampaProdotti(24)'> - Hub </p>";
echo"<p class='sottocategoria' id=8c style='display:none' onclick='stampaProdotti(25)'> - Modem </p>";

echo"<p class='categoria' id=9 onclick='evidenziaSottocategoria(this.id)'>Scansione e Stampa</p>";
echo"<p class='sottocategoria' id=9a style='display:none' onclick='stampaProdotti(26)'> - Copiatrici digitali </p>";
echo"<p class='sottocategoria' id=9b style='display:none' onclick='stampaProdotti(27)'> - Multifunzione ink-jet </p>";
echo"<p class='sottocategoria' id=9c style='display:none' onclick='stampaProdotti(28)'> - Scanner </p>";

echo"<p class='categoria' id=10 onclick='evidenziaSottocategoria(this.id)'>Software</p>";
echo"<p class='sottocategoria' id=10a style='display:none' onclick='stampaProdotti(30)'> - Adobe </p>";
echo"<p class='sottocategoria' id=10b style='display:none' onclick='stampaProdotti(31)'> - Corel </p>";
echo"<p class='sottocategoria' id=10c style='display:none' onclick='stampaProdotti(32)'> - Nikon </p>";

echo"<p class='categoria' id=11 onclick='evidenziaSottocategoria(this.id)'>Telefonia</p>";
echo"<p class='sottocategoria' id=11a style='display:none' onclick='stampaProdotti(33)'> - Fax </p>";
echo"<p class='sottocategoria' id=11b style='display:none' onclick='stampaProdotti(34)'> - Smartphone </p>";
echo"<p class='sottocategoria' id=11c style='display:none' onclick='stampaProdotti(35)'> - Telefonia fissa </p>";

echo"<p class='categoria' id=12 onclick='evidenziaSottocategoria(this.id)'>Video</p>";
echo"<p class='sottocategoria' id=12a style='display:none' onclick='stampaProdotti(36)'> - Videocamere </p>";
echo"<p class='sottocategoria' id=12b style='display:none' onclick='stampaProdotti(37)'> - Decoder </p>";
echo"<p class='sottocategoria' id=12c style='display:none' onclick='stampaProdotti(38)'> - Videoproiettori </p>";

?>