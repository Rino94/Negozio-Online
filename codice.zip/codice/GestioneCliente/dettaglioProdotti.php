<?php
/*
CASO D'USO:dettaglioProdotto
1.	Il caso d’uso inizia quando il Cliente clicca su un prodotto.
2.	Il Sistema mostra i dettagli del prodotto selezionato
3.	Se il Cliente seleziona “Aggiungi al Carrello” 
<aggiungiAlCarrello>


*/
//Recupero ID della sottocategoria per la quale devo stampare i prodotti
	$IDp=$_GET['IDp'];
	
	
//Accedo a m_prodotti e per ogni IDs==$IDs stampo tabella (devo recuperare anche quantita in p_prodotti)
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM m_prodotti WHERE IDprodotto=$IDp";
	$risultato=mysql_query($query) or die(mysql_error()); 
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
		$idP=$riga['IDprodotto'];
		$n=$riga['Nome'];
		$d=$riga['Descrizione'];
		$st=$riga['Scheda_Tecnica'];
		$p=$riga['Prezzo'];
		$i=$riga['Immagine'];
		$g=$riga['Giacenza'];
		
//Controllo in p_prodotti se ci sono prodotti in arrivo
	$tot=0;
	$query2=" SELECT * FROM p_prodotti WHERE IDprodotto=$idP";
	$risultato2=mysql_query($query2) or die(mysql_error()); 
	while($riga2=mysql_fetch_array($risultato2,MYSQL_ASSOC)){
		foreach($riga2 as $campo => $valore) 
		$q=$riga2['quantita'];
		$tot=$tot+$q;
	}
	mysql_free_result($risultato2);
	
//Creo Tabella
echo "<table>";
echo "<tr><td colspan='2' class='nomeTab'>$n</td></tr>";
echo "<tr><td colspan='2' class='codTab'>Cod: $idP - Disponibilit': $g - In arrivo: $tot</td></tr>";
echo "<tr><td rowspan='2'> <img src='../GestioneMagazzino/immProdotti/$i' width=200px> </td><td><b>Scheda Tecnica:</b><br>$st</td></tr>";
echo "<tr><td class='prezzo'>PREZZO: <b>$p &euro;</b> </td></tr>";

if(($g>0)&&($tot>0)) {
	echo "<tr><td colspan='2' class='carr' onclick='settaCOOKIE($idP)'> AGGIUNGI AL CARRELLO </td></tr>";
}
else {
	echo "<tr><td colspan='2' class='carr' onclick='alert(\"Spiacente, prodotto attualmente non disponibile!\")'> AGGIUNGI AL CARRELLO </td></tr>";
}

echo "<tr><td colspan='2'><br><b> DESCRIZIONE:<br> </b><br> $d </td></tr></table>";

		
	}
	mysql_free_result($risultato);
	mysql_close($cn);
	
?>