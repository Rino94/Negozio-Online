<?php session_start(); ?>
<html>
<head>
<title>Negozio Online </title>
<style type="text/css">
@import "GestioneCliente.css";
</style>
<script type="text/javascript" src="funzioniJS.js"> </script>
<script type="text/javascript"> x=0; </script>
</head>
<body>
<!--controllo se c'è una sessione attiva -->
<?php
if(isset($_SESSION['nick']))	
	$n=$_SESSION['nick'];
?>

<form method='get' action='cercaNomeProdotto.php'> <!-- form per ricerca prodotto -->
<div id='contenitore'>
		
	<div id='intestazione'> <img src='../image/logo.jpg' height=75px> <a class='c' href='index.php'><span class='a'>NEGOZI<b>O</b></span><span class='b'>NLINE</span></a> 
		<div class='ric'> <input type='text' name='nome'><input  type='submit' value='cerca'></form><br>
		<?php if(isset($n)) echo "Salve, $n";
		?></div>
	</div>	<div id='centro'>

		<div id='menu'> <?php include("menu.php");?> </div>

		<div id='info'> <?php include("areaCliente.php");?> </div>
		
		<div id='page'>
<!--
CASO D'USO: effettuoLogin
1.	Il Cliente inserisce le sue credenziali e conferma cliccando su “Login”.
-->
			<form method='post' action='controlLogin.php'>
			<table> <tr><td>Username: </td><td><input type='text' name='username'></td></tr>
					<tr><td>Password: </td><td><input type='password' name='password'></td></tr>
					<?php
						if (isset($_GET['k'])) echo "<tr><td colspan=2> Username o Password inseriti NON corretti</td></tr>";
					?>
					<tr><td colspan='2'> <input type='submit' value='Login'></td></tr>
			
			</table>
			</form>
		</div>
			
	</div>
	
	<div id='footer'>  </div>
	
	
</div> 

</body>
</html>