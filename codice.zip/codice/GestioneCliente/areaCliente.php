<?php
if(!isset($n)) { //se non ho ancora effettuato l'accesso allora:
/*
CASO D'USO: areaCliente
	1.Se il Cliente clicca su "Login" <effettuaLogin>
*/
	echo"<p class='ac2'> <a class='ac' href='login.php'>Login</a> </p>";
/*
CASO D'USO: areaCliente
	1.Se il Cliente clicca su "Iscriviti" <effettuaIscrizione>
*/
	echo"<p class='ac2'> <a class='ac' href='iscriviti.php'>Iscriviti</a> </p>";
/*
CASO D'USO: areaCliente
	1.Se il Cliente clicca su "Recupera password" <recuperaPassword>
*/
	echo"<p class='ac2'> <a class='ac' href='recuperaPass.php'>Recupera Password</a> </p>";

}
else { //se sono stato autenticato:
	echo"<p class='ac2'> <a class='ac' href='logout.php'>Logout</a> </p>";

/*
CASO D'USO: effettuaLogin
	5.	Se il Cliente seleziona “Modifica account”
<modificaAccount>

*/	
echo"<p class='ac2'> <a class='ac' href='modificaAccount.php'>Modifica Account</a> </p>";
/*
CASO D'USO: effettuaLogin
	6.	Se il Cliente seleziona “Elimina account”
<eliminaAccount>

*/
echo"<p class='ac2'> <a class='ac' href='eliminaAccount.php'>Elimina Account</a> </p>";
/*
CASO D'USO: effettuaLogin
	7.	Se il Cliente seleziona “Dettagli Account”
<stampaDettagliAccount>

*/
echo"<p class='ac2'> <a class='ac' href='dettagliAccount.php'>Dettagli Account</a> </p>";
}
//in ogni caso:	
echo"<p class='ac2'> <a class='ac' href='assistenza.php'>Chiedi assistenza</a> </p>";

/*
CASO D'USO: dettaglioCarrello
	7.	Se il Cliente seleziona “Dettagli Carrello”
<DettagliCarrello>

*/
echo"<p class='ac2'> <a class='ac' href='dettagliCarrello.php'>Dettagli Carrello</a> </p>";

?>