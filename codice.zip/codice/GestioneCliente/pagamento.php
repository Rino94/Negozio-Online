<?php
	//recupero valori
	$prezzo=$_POST['prezzo'];
	
	//dati cliente
	$IDcliente=$_POST['IDcliente'];
	$nomeC=$_POST['nome'];
	$cognome=$_POST['cognome'];
	$citta=$_POST['citta'];
	$prov=$_POST['prov'];
	$CAP=$_POST['CAP'];
	$via=$_POST['via'];
	
	//prodotti
		$id = $_POST['idd'];
		$q=$_POST['qua'];
		$n=count($id);
	
	//memorizzo per invio
		//prezzo
	echo"<form method='post' action='controlPagamento.php'>";
	echo"<input type='hidden' name='prezzo' value='$prezzo'>";


		//dettagli cliente
		echo"<input type='hidden' name='IDcliente' value='$IDcliente'>";
		echo"<input type='hidden' name='nome' value='$nomeC'>";
		echo"<input type='hidden' name='cognome' value='$cognome'>";
		echo"<input type='hidden' name='citta' value='$citta'>";
		echo"<input type='hidden' name='prov' value='$prov'>";
		echo"<input type='hidden' name='CAP' value='$CAP'>";
		echo"<input type='hidden' name='via' value='$via'>";
		
		//prodotti e quantita
		for($i=0;$i<$n;$i++) {
		$aa=$id[$i];
		$bb=$q[$i];
		echo"<input type='hidden' name='idd[]' value='$aa'>";
		echo"<input type='hidden' name='qua[]' value='$bb'>";
		}

	
	//tabella
	
	echo"<center>";
	echo"<table>";
	echo"<tr><td colspan=2><b>Informazioni per l'acquisto</td></tr>";
	echo"<tr><td>Merchant</td><td>Negozio Online</td></tr>";
	echo"<tr><td>Sito Web</td><td>http://wwww.nogoziOnline.it</td></tr>";
	echo"<tr><td>Importo</td><td>Eur $prezzo</td></tr>";
	echo"<tr><td>Numero ordine</td><td> </td></tr>";
	echo"<tr><td colspan=2><b>Informazioni per il pagamento</td></tr>";
	echo"<tr><td>Carte accettate</td><td></td></tr>";
	echo"<tr><td>Carta di Credito n°</td><td></td></tr>";
	echo"<tr><td>CVV2/CVC2</td><td></td></Tr>";
	echo"<tr><td>Data scadenza</td><td></td></tr>";
	echo"<tr><td>Nome titolare</td><td></td></tr>";
	echo"<tr><td></td><td><input type='submit' value='Paga ora'></td></tr>";
	echo"<tr><td colspan=2><b>Informativa Privacy</td></tr>";
	echo"<tr><td colspan=2>privacy</td></tr>";
	echo"</table>";
?>