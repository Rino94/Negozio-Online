<?php session_start(); ?>
<html>
<head>
<title>Negozio Online </title>
<style type="text/css">
@import "GestioneCliente.css";
</style>
<script type="text/javascript" src="funzioniJS.js"> </script>
<script type="text/javascript"> x=0; </script>
</head>
<body>
<!--controllo se c'è una sessione attiva -->
<?php
if(isset($_SESSION['nick']))	
	$n=$_SESSION['nick'];
?>

<form method='get' action='cercaNomeProdotto.php'> <!-- form per ricerca prodotto -->
<div id='contenitore'>
		
	<div id='intestazione'> <img src='../image/logo.jpg' height=75px> <a class='c' href='index.php'><span class='a'>NEGOZI<b>O</b></span><span class='b'>NLINE</span></a> 
		<div class='ric'> <input type='text' name='nome'><input type='submit' value='cerca'></form><br>
		<?php if(isset($n)) echo "Salve, $n";
		?></div>
<div id='centro'>

		<div id='menu'> <?php include("menu.php");?></div>

		<div id='info'> <?php include("areaCliente.php");?> </div>
		
		<div id='page'> <?php include("cercaNome.php");?> </div>
			
	</div>
	
	<div id='footer'> Footer </div>
	
	
</div> 

</body>
</html>