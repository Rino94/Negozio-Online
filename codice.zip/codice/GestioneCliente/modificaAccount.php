<?php session_start(); ?>
<html>
<head>
<title>Negozio Online </title>
<style type="text/css">
@import "GestioneCliente.css";
</style>
<script type="text/javascript" src="funzioniJS.js"> </script>
<script type="text/javascript"> x=0; </script>
</head>
<body>
<!--controllo se c'è una sessione attiva -->
<?php
if(isset($_SESSION['nick']))	
	$n=$_SESSION['nick'];
?>

<form method='get' action='cercaNomeProdotto.php'> <!-- form per ricerca prodotto -->
<div id='contenitore'>
		
	<div id='intestazione'> <img src='../image/logo.jpg' height=75px> <a class='c' href='index.php'><span class='a'>NEGOZI<b>O</b></span><span class='b'>NLINE</span></a> 
		<div class='ric'> <input type='text' name='nome'><input type='submit' value='cerca'></form><br>
		<?php if(isset($n)) echo "Salve, $n";
		?></div>
	</div>


	<div id='centro'>

		<div id='menu'> <?php include("menu.php");?> </div>

		<div id='info'> <?php include("areaCliente.php");?> </div>
		
<div id='page'>
<?php
if(!isset($_GET['ins'])){

//Accedo al DB per recuperare i dati
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM cliente WHERE Username='$n'";
	$risultato=mysql_query($query);
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
				$Nome=$riga['Nome'];
				$Cognome=$riga['Cognome'];
				$DataNascita=$riga['DataNascita'];
				$LuogoResidenza=$riga['LuogoResidenza'];
				$Provincia=$riga['Provincia'];
				$CAP=$riga['CAP'];
				$Via=$riga['Via'];
				$Email=$riga['Email'];
				
			echo "<form method='POST' action='ControlModificaCliente.php' onsubmit='return controllaModifica()'>";
				
				echo "<div class='tabella'>";
				echo "<table>";
				echo "<tr><td colspan='2'><b>Modifica Dati Cliente</b><br><br></td>";
				echo"<tr><td><b>Nome:</b></td><td><input type='text' name='nome' value='$Nome' id='aa' onkeyup='controlloTest(this.value,\"a\")'></td><td id='a'></td></tr>";
				echo"<tr><td><b>Cognome:</b></td><td><input type='text' name='cognome' value='$Cognome' id='bb' onkeyup='controlloTest(this.value,\"b\")'></td><td id='b'></td></tr>";
				echo"<tr><td><b>Username:</b></td><td><input type='text' name='username' value='$n' id='cc' onkeyup='controlloChar(this.value,\"c\")'></td><td id='c'></td></tr>";
				echo"<tr><td><b>Data Nascita:</b></td><td><input type='text' name='DataNascita' value='$DataNascita' id='ff' onkeyup='controlloData(this.value,\"f\")'></td><td id='f'></td></tr>";
				echo"<tr><td><b>LuogoResidenza:</b></td><td><input type='text' name='LuogoResidenza' value='$LuogoResidenza' id='gg' onkeyup='controlloTest(this.value,\"g\")'></td><td id='g'></td></tr>";
				echo"<tr><td><b>Provincia:</b></td><td><input type='text' name='Provincia' value='$Provincia' id='ll' onkeyup='controlloPro(this.value,\"l\")' maxlength='2' size=2></td><td id='l'></td></tr>";
				echo"<tr><td><b>CAP:</b></td><td><input type='text' name='CAP' value='$CAP' id='ii' onkeyup='controlloCAP(this.value,\"i\")' maxlength='5' size=5></td><td id='i'></td></tr>";
				echo"<tr><td><b>Via:</b></td><td><input type='text' name='Via' value='$Via' id='mm' onkeyup='controlloVia(this.value,\"m\")'></td><td id='m'></td></tr>";
				echo"<tr><td><b>Email:</b></td><td><input type='text' name='Email' value='$Email' id='nn' onkeyup='controlloEmail(this.value,\"n\")'></td><td id='n'></td></tr>";
				echo "<tr><td colspan='2'><br> <input type='submit' value='Conferma' id='s'> </td></tr>";
				echo"</table></form>";	
							
}
mysql_free_result($risultato);
mysql_close($cn);

}
else
echo"Modifica avvenuta correttamente";
?>



</div>
			
	</div>
	
	<div id='footer'>  </div>
	
	
</div> 

</body>
</html>