<?php
/*
1.	Il Sistema stampa a video tutti i dettagli relativi ai prodotti che il cliente ha inserito nel carrello.
2.	Se il Cliente modifica la quantità di un prodotto
<modificaCarrello>
3.	Se il Cliente seleziona “Acquista”
<Acquista>
*/
	$cookie=$_GET['cookie'];
	
	$idPr=explode('abc',$cookie);
	$n=count($idPr);
	$n=$n-1;
	echo"<table width='540'>";
	$totale=0;
	for($i=0;$i<$n;$i++){ //Per ogni prodotto:
	$idP=$idPr[$i];
	
	
-//Accedo al DB e recupero le informazione riguardante il prodotto	
		$cn = mysql_connect("localhost","root");
		mysql_select_db("negozionline");
		$query=" SELECT * FROM m_prodotti WHERE IDprodotto=$idP";
		$risultato=mysql_query($query) or die(mysql_error()); 
		while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
			foreach($riga as $campo => $valore) 
			$nom=$riga['Nome'];
			$st=$riga['Scheda_Tecnica'];
			$p=$riga['Prezzo'];
			$im=$riga['Immagine'];
			$g=$riga['Giacenza'];
			$totale=$totale+$p;
/*
CASO D'USO: modificaQuantità
1.	Il caso d’uso inizia quando il Cliente ha modificato la quantità di acquisto di un prodotto.
2.	Finché si verificano errori durante l’inserimento dei dati
2.1. Il Sistema visualizza un messaggio che descrive lo scenario.
2.2. Il Sistema consente il Cliente di correggere l’errore.
2.3. Il Cliente modifica tutti o parte dei dati.
3.	Altrimenti:
3.1. Il Sistema conferma l’avvenuto inserimento.
*/

/*
CASO D'USO:eliminaProdotto
1.	Il caso d’uso inizia quando il Cliente ha cliccato sull’icona per eliminare un prodotto dal carrello.
2.	Il sistema elimina il prodotto dal carrello.


*/
			echo"<tr><td><img src='../GestioneMagazzino/immProdotti/$im' width=80px></td><td width='200'><b>$nom</b><br>$st</td><td><b>$p</b>&#8364</td><td>Q.ta <input onkeyup='return controllaGiac(this.value,$g)' type='text' style='width: 25' name='quant[]'>/$g</td><td><p id='$idP' onclick='eliminaProdotto(this.id)'>Elimina</p></td></tr>";
			echo"<input type='hidden' name='idProd[]' value='$idP'";
			
		}
	}
	echo"<tr><td colspan=5>TOTALE= $totale <input type='submit' value='Acquista'></td></tr>";
	
	echo"</table>";
	mysql_free_result($risultato);
	mysql_close($cn);

?>