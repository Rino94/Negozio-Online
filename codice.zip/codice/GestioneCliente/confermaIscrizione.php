<?php
//recupero i dati
	$nome=$_POST['nome'];
	$cognome=$_POST['cognome'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$datan=$_POST['datan'];
	$luogon=$_POST['luogon'];
	$residenza=$_POST['residenza'];
	$cap=$_POST['cap'];
	$prov=$_POST['prov'];
	$via=$_POST['via'];
	$email=$_POST['email'];
	
//Accedo al DB e inserisco i dati relativi al Cliente.
$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline",$cn);
$query = "INSERT INTO cliente (Nome,Cognome,Username,Password,DataNascita,LuogoNascita,LuogoResidenza,Provincia,CAP,Via,Email)  VALUES ('$nome','$cognome','$username','$password','$datan','$luogon','$residenza','$prov','$cap','$via','$email')"; 

mysql_query($query,$cn) or die (mysql_error());
mysql_close($cn);	

//Torno alla pagina di inserimento e notifico l'avvenuto inserimento
header ("location: iscriviti.php?ins=1");
	
?>