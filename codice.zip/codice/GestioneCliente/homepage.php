<?php
if (!isset($_GET['ins'])) {



//Recupero ID della sottocategoria per la quale devo stampare i prodotti

	$IDs=1;
//Accedo al m_prodotti e per ogni IDs==$IDs stampo tabella (devo recuperare anche quantita in p_prodotti)
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM m_prodotti WHERE IDs=$IDs";
	$risultato=mysql_query($query) or die(mysql_error()); 
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
		$idP=$riga['IDprodotto'];
		$n=$riga['Nome'];
		$st=$riga['Scheda_Tecnica'];
		$p=$riga['Prezzo'];
		$im=$riga['Immagine'];
		$g=$riga['Giacenza'];
		
//Controllo in p_prodotti se ci sono prodotti in arrivo
	$tot=0;
	$query2=" SELECT * FROM p_prodotti WHERE IDprodotto=$idP";
	$risultato2=mysql_query($query2) or die(mysql_error()); 
	while($riga2=mysql_fetch_array($risultato2,MYSQL_ASSOC)){
		foreach($riga2 as $campo => $valore) 
		$q=$riga2['quantita'];
		$tot=$tot+$q;
	}
	mysql_free_result($risultato2);
		
//Creo tabella
	echo"<table class='tab'><tr><td><img src='../GestioneMagazzino/immProdotti/$im' width=100px></td><td><b>$n</b><br>cod.$idP<br>$st</td><td width=100px>Disponibilita': <b>$g</b><br>In arrivo: <b>$tot</b><br>Prezzo:<b>$p &#8364</b></td></tr><tr><td></td><td><a href='TabellaDettagliProdotti.php?IDp=$idP'>- Dettagli</a></td><td></td></tr></table>";
	}
	mysql_free_result($risultato);
	mysql_close($cn);

}
else if (($_GET['ins'])==0)
	echo"Account Eliminato";
else if (($_GET['ins'])==1)
	echo"Ordine Effettuato!";
?>