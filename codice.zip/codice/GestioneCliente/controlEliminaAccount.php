<?php
session_start();
$n=$_SESSION['nick'];



//Accedo al DB e modifico i dati di accesso.
$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline",$cn);
$query = "UPDATE cliente SET Password='xxxxxxxxxx',Username='xxxxxxxxxx' WHERE Username='$n'";
mysql_query($query,$cn) or die(mysql_error());
mysql_close($cn);

//DISTRUGGO sessione e torno alla home
session_start();
$_SESSION['nick'] = array();
session_destroy();
header('location: index.php?ins=0');
exit();
?>