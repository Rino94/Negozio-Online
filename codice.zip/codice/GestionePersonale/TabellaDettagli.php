<?php	
	
//CASO D'USO: selezionaPersonale
//	2.	Il Sistema mostra i dettagli della persona	
	echo "<table>";
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM dettaglipersonale";
	$risultato=mysql_query($query);
	$k=0;
	while(($riga=mysql_fetch_array($risultato,MYSQL_ASSOC))&&($k==0)){
		foreach($riga as $campo => $valore) 
			$idP=$riga['IDpersonale'];
			if ($idP==$id) {
				$k=1;
				$n=$riga['Nome'];
				$c=$riga['Cognome'];
				$d=$riga['DataNascita'];
				$r=$riga['Ruolo'];
				$u=$riga['Username'];
		
				echo"<tr class='dispari'><td><b>ID:</b></td><td>$idP</td></tr>";
				echo"<tr class='pari'><td><b>Nome:</b></td><td>$n</td></tr>";
				echo"<tr class='dispari'><td><b>Cognome:</b></td><td>$c</td></tr>";
				echo"<tr class='pari'><td><b>Data di Nascita:</b></td><td>$d</td></tr>";
				echo"<tr class='dispari'><td><b>Ruolo:</b></td><td>$r</td></tr>";
				echo"<tr class='pari'><td><b>Username:</b></td><td>$u</td></tr>";
			}
	}
	
/*CASO D'USO: selezionaPersonale
	3.	Se l’Amministratore seleziona “Modifica” <modifica>
	4.	Se l’Amministratore seleziona “Elimina” <elimina>
*/
				echo"<tr><td colspan='2'><center><input type='button' value='Modifica' onclick=\"location.href='modificaPersonale.php?id=$idP&n=$n&c=$c&d=$d&r=$r&u=$u'\">";
				echo"<input type='button' value='Elimina' onclick=\"location.href='ControlEliminaPersonale.php?IDp=$idP'\"></center></td></tr>";
	echo"</table>";
mysql_free_result($risultato);
mysql_close($cn);
		
?>