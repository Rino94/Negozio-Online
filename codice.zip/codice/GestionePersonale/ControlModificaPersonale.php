<?php
//Recupero i dati
	$IDpersonale = $_GET['IDp'];
	$nome = $_GET['nome'];
	$cognome = $_GET['cognome'];
	$dataNascita = $_GET['dataNascita'];
	$IDruolo = $_GET['ruolo'];
	$user = $_GET['username'];
	

	if ($IDruolo==1) $ruolo="Aministratore";
	if ($IDruolo==2) $ruolo="CapoMagazzino";
	if ($IDruolo==3) $ruolo="Magazziniere";

//Accedo al DB e modifico i dati.
$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline",$cn);
$query = "UPDATE dettaglipersonale SET Nome='$nome',Cognome='$cognome',DataNascita='$dataNascita',Ruolo='$ruolo',IDruolo='$IDruolo',Username='$user' WHERE IDpersonale='$IDpersonale'";
mysql_query($query,$cn) or die("errore");
mysql_close($cn);

//Torno alla pagina di inserimento e notifico l'avvenuto inserimento
header ("location: modificaPersonale.php?ins=1");	
	?>