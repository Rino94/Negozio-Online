function ajaxFunctionTabellaPersonale(sel){
	if (sel!=0)
		var val = sel.options[sel.selectedIndex].value;
	else
		var val = 0;
	
	var v = new XMLHttpRequest();
	v.onreadystatechange=function() {
		if(v.readyState==4) {
			document.getElementById("tabella").innerHTML=v.responseText;
		}
	}
	v.open("GET","tabella.php?id="+val,true);
	v.send(null);
}
	
function controlloNome(testo){
	var patt = /^([a-zA-Z\xE0\xE8\xE9\xF9\xF2\xEC\x27]\s?){4,30}$/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById("nome").innerHTML="<p class='vero'><b>OK</b></p>";
			document.getElementById("c").removeAttribute("disabled");

		}
		else {
			document.getElementById("nome").innerHTML="<p class='falso'><b>errore</b></p>";
			document.getElementById("c").setAttribute("disabled",false);

			}
}

function controlloCognome(testo){
	var patt = /^([a-zA-Z\xE0\xE8\xE9\xF9\xF2\xEC\x27]\s?){4,30}$/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById("cognome").innerHTML="<p class='vero'><b>OK</b></p>";
			document.getElementById("dn").removeAttribute("disabled");

		}
		else {
			document.getElementById("cognome").innerHTML="<p class='falso'><b>errore</b></p>";
			document.getElementById("dn").setAttribute("disabled",false);

		}
}

function controlloData(testo){
	var patt = /^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[-/.](19|20)\d\d/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById("data").innerHTML="<p class='vero'><b>OK</b></p>";
			document.getElementById("u").removeAttribute("disabled");

		}
		else {
			document.getElementById("data").innerHTML="<p class='falso'><b>errore</b></p>";
		document.getElementById("u").setAttribute("disabled",false);

		}
}

function controlloUsername(testo){
	var patt = /^([a-zA-Z0-9\.\_\-])+$/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById("username").innerHTML="<p class='vero'><b>OK</b></p>";
			document.getElementById("pass1").removeAttribute("disabled");

		}
		else {
			document.getElementById("username").innerHTML="<p class='falso'><b>errore</b></p>";
			document.getElementById("pass1").setAttribute("disabled",false);

		}
}

function controlloPass(testo){
	var patt = /^[a-zA-Z0-9\_\*\-\+\!\?\.\xE0\xE8\xE9\xF9\xF2\xEC\x27]{6,12}/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById("pass").innerHTML="<p class='vero'><b>OK</b></p>";
			document.getElementById("rp").removeAttribute("disabled");

		}
		else {
			document.getElementById("pass").innerHTML="<p class='falso'><b>errore</b></p>";
			document.getElementById("rp").setAttribute("disabled",false);

		}
}

function controlloRpass(p1){
		p2=document.getElementById('pass1');
		p2=p2.value;
		if (p1==p2) {
			document.getElementById("Rpass").innerHTML="<p class='vero'><b>OK</b></p>";
			document.getElementById("s").removeAttribute("disabled");

		}
		else {
			document.getElementById("Rpass").innerHTML="<p class='falso'><b>errore</b></p>";
			document.getElementById("s").setAttribute("disabled",false);

		}
}




