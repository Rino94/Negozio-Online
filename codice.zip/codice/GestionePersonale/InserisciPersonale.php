<?php session_start(); ?>

<html>
<head>
<title> Gestione Personale </title>
<style type="text/css">
@import "Personale.css";
@import "InserisciPersonale.css";
</style>
<script type="text/javascript" src="funzioniJS.js"> </script>
</head>
<body>
<?php
	if(!isset($_SESSION['nik']))	
		echo "Connessione fallita!!!";
	else {
		$n=$_SESSION['nik'];
		echo "<div class='contenitore'>";
		include("../intestazionePersonale.php");
		echo "<div class='home'> <a href='GestionePersonale.php'>-Home </a> </div>";
		
		//controllo se precedentemente è stato effettuato un inserimento da notificare
		if(!isset($_GET['ins'])) $ins=0; else $ins=1;
			
		
		
/*CASO D'USO: inserisciPersonale
			1.	L’Amministratore inserisce i dati e conferma l’inserimento selezionando “Conferma”.
			2.	Il Sistema memorizza i dati appena inseriti.
			3.	Finché si verificano errori durante l’inserimento dei dati
				3.1. Il Sistema visualizza un messaggio che descrive lo scenario.
				3.2. Il Sistema consente all’Amministratore di correggere l’errore.
				3.3. L’Amministratore modifica tutti o parte dei dati.
				3.4. L’Amministratore avvia la registrazione dei dati, facendo clic sul pulsante “Conferma”.
			4.	Altrimenti:
				4.1. Il Sistema conferma l’avvenuto inserimento.			
*/
		echo "<div class='formInserisci'>";	
			echo "<table>";
			echo "<form method='get' action='ControlInserisciPersonale.php'>";
				echo "<tr><td colspan='3'><b>Inserisci Personale</b><br><br></td>";
				echo "<tr><td>Nome</td><td><input type='text' name='nome'  onkeyup='controlloNome(this.value)'></td><td id='nome'></td></tr> ";
				echo "<tr><td>Cognome</td><td><input type='text' name='cognome' onkeyup='controlloCognome(this.value)' disabled='true' id='c'></td><td id='cognome'></td></tr> ";
				echo "<tr><td>Data di Nascita</td><td><input type='text' name='dataNascita' value='gg.mm.aaaa' onkeyup='controlloData(this.value)' disabled='true' id='dn'></td><td id='data'></td></tr> ";
				echo "<tr><td>Ruolo</td><td><select name='ruolo'><option value='1'>Amministratore</option><option value='2'>Capo Magazzino</option><option value='3'>Magazziniere</option></select></td><td></td></tr> ";
				echo "<tr><td>Username</td><td><input type='text' name='username' onkeyup='controlloUsername(this.value)' disabled='true' id='u'></td><td id='username'></td></tr> ";
				echo "<tr><td>Password</td><td><input type='password' name='password'onkeyup='controlloPass(this.value)' id='pass1' disabled='true'></td><td id='pass'></td></tr>";
				echo "<tr><td>Ripeti Password</td><td><input type='password' name='Rpassword' onkeyup='controlloRpass(this.value)' disabled='true' id='rp'></td><td id='Rpass'></td></tr>";
				echo "<tr><td colspan='3'><br> <input type='submit' value='Conferma' disabled='true' id='s'> </td><td></td></tr>";
				
				if($ins==1)
					echo "<tr><td colspan='3'><p class='ins'> Inserimento avvenuto con successo </p></td></tr>";
				
				echo "</table>";
		echo "</div>";
		
		echo "</div>";
	}
?>