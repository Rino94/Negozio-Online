<?php
//Recupero i dati
	$nome = $_GET['nome'];
	$cognome = $_GET['cognome'];
	$dataNascita = $_GET['dataNascita'];
	$IDruolo = $_GET['ruolo'];
	$user = $_GET['username'];
	$pass = $_GET['password'];
	
	if ($IDruolo==1) $ruolo="Aministratore";
	if ($IDruolo==2) $ruolo="CapoMagazzino";
	if ($IDruolo==3) $ruolo="Magazziniere";
	
//Accedo al DB e inserisco i dati.
$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline",$cn);
$query = "INSERT INTO dettagliPersonale (Nome,Cognome,DataNascita,Ruolo,IDruolo,Username,Password)  VALUES ('$nome','$cognome','$dataNascita','$ruolo','$IDruolo','$user','$pass')";
mysql_query($query,$cn);
mysql_close($cn);

//Torno alla pagina di inserimento e notifico l'avvenuto inserimento
header ("location: InserisciPersonale.php?ins=1");	
	?>