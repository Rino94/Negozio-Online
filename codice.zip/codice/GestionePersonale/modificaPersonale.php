<?php session_start(); ?>

<html>
<head>
<title> Gestione Personale </title>

<style type="text/css">
@import "Personale.css";
@import "GestionePersonale.css";
@import "InserisciPersonale.css";
</style>
<script type="text/javascript" src="funzioniJS.js"> </script>

</head>

<body>
<?php
	if(!isset($_SESSION['nik']))	
		echo "Connessione fallita!!!";
	else {
		$n=$_SESSION['nik'];
		echo "<div class='contenitore'>";
			 include("../intestazionePersonale.php");
			 echo "<div class='home'> <a href='GestionePersonale.php'>-Home </a> </div>";
			 
			 //controllo se precedentemente è stato effettuato una modifica
		if(!isset($_GET['ins'])) {
			$ins=0; 
			$idP=$_GET['id'];
			$n=$_GET['n'];
			$c=$_GET['c'];
			$d=$_GET['d'];
			$r=$_GET['r'];
			$u=$_GET['u'];
				
/*
CASO D'USO: modificaPersonale
1.	L’Amministratore inserisce i dati o il dato da modificare e conferma selezionando “Conferma”.
2.	Il Sistema memorizza i dati appena inseriti.
3.	Finché si verificano errori durante l’inserimento dei dati
	3.1. Il Sistema visualizza un messaggio che descrive lo scenario.
	3.2. Il Sistema consente all’Amministratore di correggere l’errore.
	3.3. L’Amministratore modifica tutti o parte dei dati.
	3.4. L’Amministratore avvia la registrazione dei dati, facendo clic sul pulsante “Conferma”.


*/
			echo "<div class='tabella'>";
				echo "<table>";
				echo "<form method='get' action='ControlModificaPersonale.php'>";
				echo "<tr><td colspan='3'><b>Modifica Personale</b><br><br></td>";
				echo "<tr><td></td><td><input type='hidden' name='IDp' value='$idP'></td><td></td> ";
				echo "<tr><td>Nome</td><td><input type='text' name='nome' value='$n'  onkeyup='controlloNome(this.value)'></td><td id='nome'></td></tr> ";
				echo "<tr><td>Cognome</td><td><input type='text' name='cognome' value='$c' onkeyup='controlloCognome(this.value)' disabled='true'  id='c'></td><td id='cognome'></td></tr> ";
				echo "<tr><td>Data di Nascita</td><td><input type='text' name='dataNascita' value='$d' value='gg/mm/aaaa'  disabled='true' onkeyup='controlloData(this.value)' id='dn'></td><td id='data'></td></tr> ";
				echo "<tr><td>Ruolo</td><td><select name='ruolo'><option value='1'>Amministratore</option><option value='2'>Capo Magazzino</option><option value='3'>Magazziniere</option></select></td><td></td></tr> ";
				echo "<tr><td>Username</td><td><input type='text' name='username' value='$u' disabled='true' onkeyup='controlloUsername(this.value)' id='u'></td><td id='username'></td></tr> ";
				echo "<tr><td colspan='3'><br> <input type='submit' value='Conferma'  id='s'> </td><td></td></tr>";
				echo "</table>";
			echo "</div>";
		}
		else
/*
CASO D'USO: modificaPersonale
	4.	Altrimenti:
		4.1. Il Sistema conferma l’avvenuto inserimento.
*/
			echo "<div class='mod'> Modifica avvenuta con successo </div>";
				
			
		echo "</div>";
	}
?>