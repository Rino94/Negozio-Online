<?php session_start(); ?>

<html>
<head>
<title> Gestione Personale </title>

<style type="text/css">
@import "Personale.css";
@import "GestionePersonale.css";
@import "InserisciPersonale.css";
</style>

</head>

<body>
<?php
	if(!isset($_SESSION['nik']))	
		echo "Connessione fallita!!!";
	else {
		$n=$_SESSION['nik'];
		echo "<div class='contenitore'>";
			 include("../intestazionePersonale.php");
			  echo "<div class='home'> <a href='GestionePersonale.php'>-Home </a> </div>";
			  
/*
CASO D'USO: eliminaPersonale
	2. Il Sistema conferma l'avvenuta operazione.
*/
		if(isset($_GET['ins'])) {
			echo "<div class='mod'> Eliminazione avvenuta con successo </div>";
			
		}

			
		echo "</div>";
	}
?>