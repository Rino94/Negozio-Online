<?php
//Recupero ID del personale da cancellare
	$IDpersonale = $_GET['IDp'];
	
/*
CASO D'USO: eliminaPersonale
	1. Il Sistema viene aggiornato
*/
$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline",$cn);
$query = "DELETE FROM dettaglipersonale WHERE IDpersonale='$IDpersonale'";
mysql_query($query,$cn) or die("errore");
mysql_close($cn);

// notifico l'avvenuta eliminazione
header ("location: eliminaPersonale.php?ins=1");
?>