<head>
<!--
/* CASO D'USO: ricercaPersonale
	1.	Il Sistema mostra un elenco di persone unitamente ai criteri di filtraggio.
		*/
-->
<style type="text/css">
@import "Personale.css";
</style>
</head>
<?php
/*
CASO D'USO: ricercaPersonale
	2.	Se l’Amministratore inserisce i criteri di ricerca:
		2.1 Il Sistema ricerca i dati che soddisfano i criteri di ricerca specificati.
*/
$id=$_GET['id'];


	echo "<table><tr><td>Nome</td><td>Cognome</td><td>Ruolo</td></tr>";

	$i=0;
	
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT nome,cognome,ruolo,IDruolo,IDpersonale FROM dettaglipersonale";
	$risultato=mysql_query($query);
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
		$n=$riga['nome'];
		$c=$riga['cognome'];
		$r=$riga['ruolo'];
		$idR=$riga['IDruolo'];
		$idP=$riga['IDpersonale'];
/*
CASO D'USO: ricercaPersonale
	2.2 Se il Sistema trova uno o più persone che soddisfano i criteri:
*/		
		if(($id == $idR)|($id == 0)) {
			$i=$i+1;
			
			
/* 
CASO D'USO:ricercaPersonale
	2.2.1 Il Sistema mostra un elenco di persone.

CASO D'USO: elencaPersonale
		4. Se l'Amministratore seleziona una determinata persona <selezionaPersona>
		
CASO D'USO: selezionaPersonale
		1.	Il caso d’uso inizia quando l’Amministratore seleziona una singola persona.
*/
			if (($i%2)== 0)
				echo "<tr class='   pari' id='$idP' onclick=\"location.href='dettagli.php?id=$idP'\"> <td> $n </td><td> $c </td><td> $r </td></tr>";
			else
				echo "<tr class='dispari' id='$idP' onclick=\"location.href='dettagli.php?id=$idP'\"><td> $n </td><td> $c </td><td> $r </td></tr>";
		}
	}
	mysql_free_result($risultato);
	mysql_close($cn);
	

?>