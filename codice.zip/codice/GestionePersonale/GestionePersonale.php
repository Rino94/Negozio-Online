<?php session_start(); ?>

<html>
<head>
<title> Gestione Personale </title>
<style type="text/css">
@import "Personale.css";
@import "GestionePersonale.css";
</style>
<script type="text/javascript" src="funzioniJS.js"> </script>
</head>
<body onload="ajaxFunctionTabellaPersonale(0)">
<?php
	if(!isset($_SESSION['nik']))	
		echo "Connessione fallita!!!";
	else {
		$n=$_SESSION['nik'];
		echo "<div class='contenitore'>";
			include("../intestazionePersonale.php");
			echo "<div class='home'> <a href='GestionePersonale.php'>-Home </a> </div>";
			echo "<div class='inserisci'> <a href='InserisciPersonale.php'>-Inserisci Personale </a> </div>";
			echo"<table class='tabella'><tr><td>";
			echo "<b>Cerca: <select name='ruolo' onchange='ajaxFunctionTabellaPersonale(this)'>";
				echo "<option value=0>Tutti</option>";
				echo "<option value=1>Amministratore</option>";
				echo "<option value=2>Capo Magazzino</option>";
				echo "<option value=3>Magazziniere</option>";
			echo "</select></div>";
			echo "</td></tr><tr><td><div id='tabella'>  </div></Td></tr></table>";
		echo "</div>";
	}
?>
</body>
</html>