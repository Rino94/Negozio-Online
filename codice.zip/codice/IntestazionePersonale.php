<?php
	echo "<div class='intestazione'><h1 class='testo'>NegoziOnline</h1></div>";
	echo "<div class='riga'> </div>";
	echo "<div class='benvenuto'> Salve <i>$n</i> </div>";
	echo "<div class='disconnetti'> <a href='../logoutPersonale.php'>-Logout </a> </div>";	
?>