<?php session_start(); ?>

<html>
<head>
<title> Gestione Magazzino </title>

<style type="text/css">
@import "../GestionePersonale/Personale.css";
@import "GestioneMagazzino.css";
</style>
<script type="text/javascript" src="funzioniJS.js"> </script>

</head>
<?php
$ids=$_GET['ids'];
echo"<body onload='opzione($ids)'>";

	if(!isset($_SESSION['nik']))	
		echo "Connessione fallita!!!";
	else {
		$n=$_SESSION['nik'];
		echo "<div class='contenitore'>";
			 include("../intestazionePersonale.php");
			 echo "<div class='home'> <a href='GestioneMagazzino.php'>-Home </a> </div>";
			 echo "<div class='inserisci'> <a href='InserisciProdotti.php'>-Inserisci Prodotti </a> </div>";

			 
			 //controllo se precedentemente è stato effettuato una modifica
		if(!isset($_GET['ins'])) {
			$ins=0; 
	$id=$_GET['id'];		
			//Accedo al DB per recuperare i dati
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM m_prodotti";
	$risultato=mysql_query($query);
	$k=0;
	while(($riga=mysql_fetch_array($risultato,MYSQL_ASSOC))&&($k==0)){
		foreach($riga as $campo => $valore) 
			$idP=$riga['IDprodotto'];
			if ($idP==$id) {
				$k=1;
				$IDs=$riga['IDs'];
				$n=$riga['Nome'];
				$d=$riga['Descrizione'];
				$st=$riga['Scheda_Tecnica'];
				$p=$riga['Prezzo'];
				$i=$riga['Immagine'];
				$g=$riga['Giacenza'];
				
				echo "<form method='POST' action='ControlModificaProdotto.php' enctype='multipart/form-data'>";
				
				echo "<div class='tabella'>";
				echo "<table>";
				echo "<tr><td colspan='2'><b>Modifica Prodotto</b><br><br></td>";
				echo "<tr><td></td><td><input type='hidden' name='IDp' value='$idP'></td></tr>";
				echo "<tr><td><b>Sottocategoria:</b></td><td><select name='IDs' id='sss'> <option>Scegli sottocategoria...</option><optgroup label='Audio'><option value='1'>Amplificatori</option> <option value='2'>Home cinema</option><option value='3'>Lettori mp3/mp4</option><optgroup label='Desktop e Notebook'> <option value='4'>Notebook</option> <option value='5'>Pc</option><option value='6'>Pc - accessori</option><optgroup label='Elettrodomestici grandi'><option value='7'>Frigoriferi</option><option value='8'>Lavastoviglie</option><option value='9'>Lavatrici</option><optgroup label='Elettrodomestici piccoli'><option value='10'>Cottura</option><option value='11'>Forni a microonde</option><option value='12'>Macchine da caffè</option><optgroup label='Fotografia'><option value='13'>Reflex</option><option value='14'>Obiettivi</option><option value='15'>Accessori foto/video</option><optgroup label='Giochi'><option value='16'>Console games</option><option value='17'>Controllees</option><option value='18'>Videogames</option><optgroup label='Monitor e periferiche'><option value='20'>Monitor LCD</option><option value='21'>Tastiere e mouse</option><option value='22'>Web-cam</option><optgroup label='Network e Wireless'><option value='23'>Firewall</option><option value='24'>Hub</option><option value='25'>Modem</option><optgroup label='Scansione e stampa'><option value='26'>Copiatrici Digitali</option><option value='27'>Multifunzione ink-jet</option><option value='28'>Scanner</option><optgroup label='Software'><option value='30'>Adobe</option><option value='31'>Corel</option><option value='32'>Nikon</option><optgroup label='Telefonia'><option value='33'>Fax</option><option value='34'>Smartphone</option><option value='35'>Telefonia Fissa</option><optgroup label='Video'><option value='36'>VideoCamere</option><option value='37'>Decoder</option><option value='38'>Videoproiettori</option></select>";
				echo"<tr><td><b>Nome:</b></td><td><input type='text' name='n' value='$n'></td></tr>";
				echo"<tr><td><b>Descrizione:</b></td><td><textarea name='d' rows='5' cols='80' >$d</textarea></td></tr>";
				echo"<tr><td><b>Scheda Tecnica:</b></td><td><textarea name='st' rows='5' cols='80' >$st</textarea></td></tr>";
				echo"<tr><td><b>Prezzo:</b></td><td><input type='text' name='p' value='$p'></td></tr>";
				echo"<tr><td><b>Immagine:</b></td><td><input type='file' name='i'></td></tr>";
				echo"<tr><td><b>Giacenza:</b></td><td><input type='text' name='g' value='$g'></td></tr>";
				echo "<tr><td colspan='2'><br> <input type='submit' value='Conferma' id='s'> </td></tr>";
				echo"</table>";
				echo "</div>";
			}
	}				
mysql_free_result($risultato);
mysql_close($cn);
	}
	else {
		echo "<div class='mod'> Modifica avvenuta con successo </div>";
	}
}
?>