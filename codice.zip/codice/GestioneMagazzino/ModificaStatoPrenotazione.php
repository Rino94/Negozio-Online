<script type="text/javascript" src="FunzioniJS.js"> </script>

<?php	
	$id=$_GET['id'];
	$dp=$_GET['dp'];
	$f=$_GET['f'];
	$Npers=$_GET['Npers'];
	$s=$_GET['s'];
	echo "<form method='GET' action='controlModificaPrenotazione.php'>";
	echo"<input type='hidden' name=id value='$id'>";
	echo "<table><tr class='dispari'><td><b>ID prenotazione</td><td><b>Data prenotazione</td><td><b>Fornitore</td><td><b>Nome Personale</td><td><b>Stato</td></tr>";
	echo "<tr class='pari'><td>$id</td><td>$dp</td><td>$f</td><td>$Npers</td>";
	echo"<td><select onchange='ControlModificaPrenotazione($s,this.value)'><option>Stato prenotazione...</option>";
	
	if ($s==0) 
		echo"<option selected value=0>Effettuata</option><option value=1>Consegnata</option></select></td></tr>";
	else
		echo"<option value=0>Effettuata</option><option selected value=1>Consegnata</option></select></td></tr>";

	echo"<tr><td colspan='5'><br><br><input type='submit' value='Conferma' disabled='disabled' id='conf'></td></tr></table>";
	
		
?>