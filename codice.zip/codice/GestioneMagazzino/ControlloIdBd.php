<?php
$IDp=$_GET['IDp'];
$k=0;
//Accedo al DB e controllo se IDp è presente
$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline");
$query=" SELECT * FROM m_prodotti";
$risultato=mysql_query($query);
while(($riga=mysql_fetch_array($risultato,MYSQL_ASSOC))&&($k==0)){
	foreach($riga as $campo => $valore)
	if (($riga["IDprodotto"] == $IDp)) {
		$k=1;
		$n=$riga["Nome"];
		$s=$riga["IDs"];
		$d=$riga["Descrizione"];
		$st=$riga["Scheda_Tecnica"];
		$p=$riga["Prezzo"];
		$imm=$riga["Immagine"];		
	}
}
mysql_free_result($risultato);
mysql_close($cn); 
if ($k==1)
	echo"$n?????$s?????$d?????$st?????$p?????$imm?????$k";
else
	echo"No!";
?>