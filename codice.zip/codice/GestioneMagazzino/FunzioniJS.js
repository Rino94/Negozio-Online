function ControlSel(v) {
	//ID Articolo
	if (v==0) {
		document.getElementById('tab').innerHTML="";
		document.getElementById('att').innerHTML= "ID Articolo: <input type='text' name='idA' id='idA'>";
		c= "<input type='button' value='Cerca' onclick='cercaIdArticolo()'>";
		
	}

	//Nome Articolo
	if (v==1) {
		document.getElementById('tab').innerHTML="";
		document.getElementById('att').innerHTML="Nome Articolo: <input type='text' name='nomeA' id='nomeA'> ";
		c= "<input type='button' value='Cerca' onclick='cercaNomeArticolo()'>";
	}
	
	//Categoria
	if (v==2) {
		document.getElementById('tab').innerHTML="";
		document.getElementById('att').innerHTML="<select id='cat' onchange='cercaCategoria()'> <option>Scegli sottocategoria...</option><optgroup label='Audio'><option value='1'>Amplificatori</option> <option value='2'>Home cinema</option><option value='3'>Lettori mp3/mp4</option><optgroup label='Desktop e Notebook'><option value='4'>Notebook</option><option value='5'>Pc</option><option value='6'>Pc - accessori</option><optgroup label='Elettrodomestici grandi'><option value='7'>Frigoriferi</option><option value='8'>Lavastoviglie</option><option value='9'>Lavatrici</option><optgroup label='Elettrodomestici piccoli'><option value='10'>Cottura</option><option value='11'>Forni a microonde</option><option value='12'>Macchine da caffè</option><optgroup label='Fotografia'><option value='13'>Reflex</option><option value='14'>Obiettivi</option><option value='15'>Accessori foto/video</option><optgroup label='Giochi'><option value='16'>Console games</option><option value='17'>Controllees</option><option value='18'>Videogames</option><optgroup label='Monitor e periferiche'><option value='20'>Monitor LCD</option><option value='21'>Tastiere e mouse</option><option value='22'>Web-cam</option><optgroup label='Network e Wireless'><option value='23'>Firewall</option><option value='24'>Hub</option><option value='25'>Modem</option><optgroup label='Scansione e stampa'><option value='26'>Copiatrici Digitali</option><option value='27'>Multifunzione ink-jet</option><option value='28'>Scanner</option><optgroup label='Software'><option value='30'>Adobe</option><option value='31'>Corel</option><option value='32'>Nikon</option><optgroup label='Telefonia'><option value='33'>Fax</option><option value='34'>Smartphone</option><option value='35'>Telefonia Fissa</option><optgroup label='Video'><option value='36'>VideoCamere</option><option value='37'>Decoder</option><option value='38'>Videoproiettori</option></select>";
		c= "";
	}
	
	//Prenotazione
	if (v==3) {
		document.getElementById('tab').innerHTML="";
		//in document.getElementById('att').innerHTML= ""; inserisco tabella con elenco prenotazioni

	var v=new XMLHttpRequest();
	v.onreadystatechange=function() {
	if(v.readyState==4) {
		document.getElementById('att').innerHTML=v.responseText;
	}
	}
	v.open("GET","tabellaPrenotazioni.php",true);
	v.send(null); 
	c=" ";
}
		
	
	
	//Giacenza
	if (v==4) {
		document.getElementById('tab').innerHTML="";
		document.getElementById('att').innerHTML="minore di: <input type='text' id='giac' name='giacenza'> ";
		c= "<input type='button'  value='Cerca' onclick='cercaGiacenza()'>";
	}
	

document.getElementById('cerca').innerHTML=c;
}

function cercaIdArticolo() {
	id=document.getElementById('idA').value;
	if (isNaN(id)) {
		alert("ATTENZIONE: ID e' composto da soli numeri!!!");
	}
	else {
		var v=new XMLHttpRequest();
		v.onreadystatechange=function() {
		if(v.readyState==4) {
			document.getElementById('tab').innerHTML=v.responseText;
		}
		}
		v.open("GET","tabellaIdArticolo.php?id="+id,true);
		v.send(null); 
	}
	}

function cercaNomeArticolo() {
	n=document.getElementById('nomeA').value;	
	var v=new XMLHttpRequest();
	v.onreadystatechange=function() {
	if(v.readyState==4) {
		document.getElementById('tab').innerHTML=v.responseText;
	}
	}
	v.open("GET","tabellaNomeArticolo.php?n="+n,true);
	v.send(null); 
}

function cercaCategoria() {
	c=document.getElementById('cat').value;	
	var v=new XMLHttpRequest();
	v.onreadystatechange=function() {
	if(v.readyState==4) {
		document.getElementById('tab').innerHTML=v.responseText;
	}
	}
	v.open("GET","tabellaCategoria.php?c="+c,true);
	v.send(null); 
}

function cercaGiacenza() {
	g=document.getElementById('giac').value;	
	var v=new XMLHttpRequest();
	v.onreadystatechange=function() {
	if(v.readyState==4) {
		document.getElementById('tab').innerHTML=v.responseText;
	}
	}
	v.open("GET","tabellaGiacenza.php?g="+g,true);
	v.send(null); 
}

function controllo() {
	IDp=document.getElementById('IDp').value;
	cat=document.getElementById('cat').value;
	nome=document.getElementById('nome').value;
	descrizione=document.getElementById('descrizione').value;
	schedaTecnica=document.getElementById('schedaTecnica').value;
	prezzo=document.getElementById('prezzo').value;
	imm=document.getElementById('imm').value;
	quantita=document.getElementById('quantita').value;
	
	if ((IDp!='')&&(cat!='')&&(nome!='')&&(descrizione!='')&&(schedaTecnica!='')&&(prezzo!='')&&(imm!='')&&(quantita!=''))
		document.write("OK");
}


function inserisciRiga() {
x=x+1;
	var v = new XMLHttpRequest();
	v.onreadystatechange = function () {
		if(v.readyState==4) {
		document.getElementById(x).innerHTML=v.responseText;
		}
	}
v.open('GET','TabellaInserisciProdotti.php?x='+x,true);
v.send(null);
}



function controlloPresenzaID(IDp,IDn) {
n="nome"+IDn;
IDs="IDs"+IDn;
cat="cat"+IDn;
descrizione="descrizione"+IDn;
schedaTecnica="schedaTecnica"+IDn;
prezzo="prezzo"+IDn;
imm="imm"+IDn;

var v = new XMLHttpRequest();
	v.onreadystatechange = function () {
		if(v.readyState==4) {
			a=v.responseText;
			var arr = a.split("?????");
			b=arr[6];			
			if (b==1) { //se l'ID è uguale allora preimposto i campi
				document.getElementById(n).setAttribute("value",arr[0]);
				document.getElementById(cat).selectedIndex=arr[1];
				document.getElementById(descrizione).innerHTML=arr[2];
				document.getElementById(schedaTecnica).innerHTML=arr[3];
				document.getElementById(prezzo).setAttribute("value",arr[4]);
				document.getElementById(imm).setAttribute("value",arr[5]);
			}
			else { //altrimenti svuoto tutto
				document.getElementById(n).setAttribute("value","");
				document.getElementById(cat).selectedIndex=0;
				document.getElementById(descrizione).innerHTML="";
				document.getElementById(schedaTecnica).innerHTML="";
				document.getElementById(prezzo).setAttribute("value","");
				document.getElementById(imm).setAttribute("value","");
			}
		}
	}
v.open('GET','ControlloIdBd.php?IDp='+IDp,true);
v.send(null);
}

function opzione(IDs) {
	document.getElementById('sss').selectedIndex=IDs;
}

function controlloData(testo){
	var patt = /^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[-/.](19|20)\d\d/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById("data").innerHTML="<p class='vero'><b>OK</b></p>";
			document.getElementById(“fn”).removeAttribute("disabled");
		}
		else {
			document.getElementById("data").innerHTML="<p class='falso'><b>errore</b></p>";
			document.getElementById(“fn”).setAttribute("disabled",false);
		}
}
function controlloNome(testo){
	var patt = /^([a-zA-Z\xE0\xE8\xE9\xF9\xF2\xEC\x27]\s?)+$/;
	var result = patt.test(testo);
		if (result==true) {
			document.getElementById("nome").innerHTML="<p class='vero'><b>OK</b></p>";
			document.getElementById(“sc").removeAttribute("disabled");
		}
		else {
			document.getElementById("nome").innerHTML="<p class='falso'><b>errore</b></p>";
			document.getElementById(“sc").setAttribute("disabled",false);
			}
}
function ControlModificaPrenotazione(Sprec,Satt) {
	if((Sprec==0)&&(Satt==1)) 
		document.getElementById('conf').disabled=false;
	else
		document.getElementById('conf').disabled=true;
	
}



