<!--
Ricevo NOME per il quale devo cercare il prodotto. Accedo al DB, cerco il prodotto con il NOME corrispondente e stampo a video le informazioni.
-->
<head>
<style type="text/css">
@import "../GestionePersonale/Personale.css";
</style>
</head>
<?php
	$n=$_GET['n'];
	$i=0;
	
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT IDprodotto,IDs,Nome,Prezzo,Giacenza FROM m_prodotti WHERE Nome='$n'";
	$risultato=mysql_query($query) or die(mysql_error()); 
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
		$idP=$riga['IDprodotto'];
		$IDs=$riga['IDs'];
		$n=$riga['Nome'];
		$p=$riga['Prezzo'];
		$g=$riga['Giacenza'];
		$i=1;
//Controllo ad IDs (ID della sottocategoria) quale sottocategoria appartiene.
	$q=" SELECT * FROM sottocategoria WHERE IDsottocategoria=$IDs";
	$ris=mysql_query($q) or die(mysql_error()); 
	while($rig=mysql_fetch_array($ris,MYSQL_ASSOC)){
		foreach($rig as $campo => $valore) 
		$IDsottoc=$rig['Nome'];
	}
	mysql_free_result($ris);		
		
		echo "<table><tr class='dispari'><td>IDprodotto</td><td>IDsottocategoria</td><td>Nome</td><td>Prezzo</td><td>Giacenza</td><td>In arrivo</td></tr>";
//inizio
//controllo in p_prodotti se e quanti prodotti relativi a $id sono stati prenotati e quindi sono in arrivo

		$tot=0;
		$query2="SELECT * FROM p_prodotti";
		$risultato2=mysql_query($query2);
		while($riga2=mysql_fetch_array($risultato2,MYSQL_ASSOC)){
			foreach($riga2 as $campo => $valore)
			$IDprodotto=$riga2['IDprodotto'];
			$q=$riga2['quantita'];
			$IDpren=$riga2['IDprenotazione'];
//controllo se lo stato della prenotazione è 0, ovvero se la prenotazione è stata effettuata ma non consegnata.
			$query3="SELECT * FROM prenotazioni WHERE IDprenotazione=$IDpren";
			$risultato3=mysql_query($query3);
			while($riga3=mysql_fetch_array($risultato3,MYSQL_ASSOC)){
				foreach($riga3 as $campo => $valore)
				$s=$riga3['Stato'];
				if($s==0) {
//fine
					if ($IDprodotto==$idP)
					$tot=$tot+$q;
				}
			}
			mysql_free_result($risultato3);
		}	
		mysql_free_result($risultato2);

//fineeee		
		

/*
CASO D'USO: elencaProdotti
	3.	Se il Capo Magazzino seleziona un determinato prodotto <selezionaProdotto>
*/
		echo "<tr class='   pari' id='$idP' onclick=\"location.href='dettagli.php?id=$idP'\"> <td> $idP </td><td> $IDsottoc </td><td> $n </td><td> $p € </td><td> $g </td><td>$tot</td></tr>";
	}
	mysql_free_result($risultato);
	mysql_close($cn);

	if ($i==0) echo"<p class='no'><b>Nessun elemento trovato!!!</b></p>";
?>