<?php session_start(); ?>

<html>
<head>
<title> Gestione Personale </title>

<style type="text/css">
@import "../GestionePersonale/Personale.css";
@import "GestioneMagazzino.css";
</style>

</head>

<body>
<?php
	if(!isset($_SESSION['nik']))	
		echo "Connessione fallita!!!";
	else {
		$n=$_SESSION['nik'];
		
		
		echo "<div class='contenitore'>";
			 include("../intestazionePersonale.php");
			 echo "<div class='home'> <a href='GestioneMagazzino.php'>-Home </a> </div>";
			 echo "<div class='inserisci'> <a href='InserisciProdotti.php'>-Inserisci Prodotti </a> </div>";

			 echo "<div class='tabella'>";
				if(isset($_GET['ins'])) {
				
					echo"<p class='ins'>Eliminazione avvenuta correttamente!!!</p>";
				}
			 echo"</div>";
			
		echo "</div>";
	}
?>