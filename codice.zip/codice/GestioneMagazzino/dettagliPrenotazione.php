<?php	
// id=$IDpren&dp=$dp&f=$f&Npers=$Npers&s=$s
	$id=$_GET['id'];
	$dp=$_GET['dp'];
	$f=$_GET['f'];
	$Npers=$_GET['Npers'];
	$s=$_GET['s'];
	
	if ($s==0) $st="effettuata";
		else if ($s==1) $st="consegnata";
		else $st="errore";
	
	echo "<table><tr class='dispari'><td><b>ID prenotazione</td><td><b>Data prenotazione</td><td><b>Fornitore</td><td><b>Nome Personale</td><td><b>Stato</td></tr>";
	echo "<tr class='pari'><td>$id</td><td>$dp</td><td>$f</td><td>$Npers</td><td>$st</td></tr></table>";
	echo"<br><br><br>";
	echo"<table>";
	echo"<tr class='dispari'><td><b>ID Prodotto:</b></td><td><b>Nome Prodotto:</b></td><td><b>Quantita':</b></td>";
	
	
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM p_prodotti";
	$risultato=mysql_query($query);
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
			$idP=$riga['IDprenotazione'];
			if ($idP==$id) {
				$IDprod=$riga['IDprodotto'];
				$q=$riga['quantita'];

	//Recupero il nome del prodotto
	$kk=0;
	$qq=" SELECT IDprodotto,Nome FROM m_prodotti";
	$ris=mysql_query($qq) or die(mysql_error()); 
	while(($rig=mysql_fetch_array($ris,MYSQL_ASSOC))&&($kk==0)){
		foreach($rig as $campo => $valore) 
		$IDp=$rig['IDprodotto'];	
			if ($IDp==$IDprod) {
				$NomeProd=$rig['Nome'];
				$kk=1;
			}
	} 
				echo"<tr class='pari'><td>$IDprod</td><td>$NomeProd</td><td>$q</td></tr>";

			}
	}


				echo"<tr><td colspan='2'><center><input type='button' value='Modifica' onclick=\"location.href='modificaPrenotazione.php?id=$id&dp=$dp&f=$f&Npers=$Npers&s=$s'\">";
				echo"<input type='button' value='Elimina' onclick=\"location.href='ControlEliminaPrenotazione.php?IDp=$id'\"></center></td></tr>";
	echo"</table>";
mysql_free_result($risultato);
mysql_close($cn);
		
?>