<?
//Recupero ID del prenotazione e prodotto da cancellare
	$IDprodotto = $_GET['IDp'];
	
	

$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline",$cn);


$query = "DELETE FROM m_prodotti WHERE IDprodotto='$IDprodotto’”;
mysql_query($query,$cn);


mysql_close($cn);

// notifico l'avvenuta eliminazione
header ("location: eliminaProdotto.php?ins=1");

?>