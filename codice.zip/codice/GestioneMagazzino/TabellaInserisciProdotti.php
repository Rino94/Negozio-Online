<?php 
$x=$_GET['x'];

echo" </div> ";

echo"<table><tr><td colspan='2'><b>Prodotti:</b></td></tr>";
	echo"<tr><td>ID Prodotto:</td><td><input type='text' name='IDp[]' id='IDp$x' onchange='controlloPresenzaID(this.value,$x)'></td></tr>";
	echo"<tr><td>Categoria:</td><td> <select name='cat[]' id='cat$x'> <option>Scegli...</option><optgroup label='Audio'><option value='1'>Amplificatori</option> <option value='2'>Home cinema</option><option value='3'>Lettori mp3/mp4</option><optgroup label='Desktop e Notebook'><option value='4'>Notebook</option><option value='5'>Pc</option><option value='6'>Pc - accessori</option><optgroup label='Elettrodomestici grandi'><option value='7'>Frigoriferi</option><option value='8'>Lavastoviglie</option><option value='9'>Lavatrici</option><optgroup label='Elettrodomestici piccoli'><option value='10'>Cottura</option><option value='11'>Forni a microonde</option><option value='12'>Macchine da caffè</option><optgroup label='Fotografia'><option value='13'>Reflex</option><option value='14'>Obiettivi</option><option value='15'>Accessori foto/video</option><optgroup label='Giochi'><option value='16'>Console games</option><option value='17'>Controllees</option><option value='18'>Videogames</option><optgroup label='Monitor e periferiche'><option value='20'>Monitor LCD</option><option value='21'>Tastiere e mouse</option><option value='22'>Web-cam</option><optgroup label='Network e Wireless'><option value='23'>Firewall</option><option value='24'>Hub</option><option value='25'>Modem</option><optgroup label='Scansione e stampa'><option value='26'>Copiatrici Digitali</option><option value='27'>Multifunzione ink-jet</option><option value='28'>Scanner</option><optgroup label='Software'><option value='30'>Adobe</option><option value='31'>Corel</option><option value='32'>Nikon</option><optgroup label='Telefonia'><option value='33'>Fax</option><option value='34'>Smartphone</option><option value='35'>Telefonia Fissa</option><optgroup label='Video'><option value='36'>VideoCamere</option><option value='37'>Decoder</option><option value='38'>Videoproiettori</option></select></td></tr>";
	echo"<tr><td>Nome: </td><td><input type='text' name='nome[]' id='nome$x'></td></tr>";
	echo"<tr><td>Descrizione:</td><td><textarea name='descrizione[]' rows='5' cols='80' id='descrizione$x'></textarea></td></tr>";
	echo"<tr><td>Scheda Tecnica:</td><td><textarea name='schedaTecnica[]' rows='5' cols='80' id='schedaTecnica$x'></textarea></td></tr>";
	echo"<tr><td>Prezzo:</td><td><input type='text' name='prezzo[]' id='prezzo$x'></td></tr>";
	echo"<tr><td>Immagine:</td><td><input type='file' name='imm[]' id='imm$x'></td></tr>";
	echo"<tr><td>Quantita':</td><td><input type='text' name='quantita[]' id='quantita$x'></td></tr>";
echo"</table>";  



$x=$x+1;
echo "<div id=$x>";

//echo"<tr><td> <b>$x</b> </td></tr></table>";
?>