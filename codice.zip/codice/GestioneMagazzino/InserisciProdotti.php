<?php session_start(); ?>
<html>
<head>
<title> Gestione Personale </title>

<style type="text/css">
@import "../GestionePersonale/Personale.css";
@import "GestioneMagazzino.css";
</style>

<script type="text/javascript" src="funzioniJS.js"> 
</script>

<script type="text/javascript">
x=0; //contatore click "Aggiungi altro prodotto..."
</script>
</head>

<body>
<?php
	if(!isset($_SESSION['nik']))	
		echo "Connessione fallita!!!";
	else {
		$n=$_SESSION['nik'];
		echo "<div class='contenitore'>";
			 include("../intestazionePersonale.php");
			 echo "<div class='home'> <a href='GestioneMagazzino.php'>-Home </a> </div>";
	//controllo se precedentemente è stato effettuato un inserimento avvenuto correttamente e da notificare
	if(isset($_GET['ins']))	echo"<div class='ins'>Prenotazione avvenuta con successo </div>";
/*
CASO D'USO: inserisciProdotti
	1.	Il capo magazzino inserisce i dati e conferma l’inserimento selezionando Conferma”.
*/	

		echo "<form method='POST' action='ControlInserisciProdotti.php'   enctype='multipart/form-data'>";			
		 
			 echo"<div class='prenotazione'>";
				echo"<table><tr><td colspan='2'><b>Prenotazione</b></td></tr><tr><td>Data prenotazione:</td><td> <input type='text' name='datapren' id='dp' value='gg/mm/aaaa' onkeyup='controlloData(this.value)'></td><td id='data'></td></tr>";
				echo"       <tr><td>Fornitore:        </td><td> <input type='text' name='fornitore' id=‘fn’  onkeyup='controlloNome(this.value)'></td><td id='nome'></td></tr></table>";
				echo "<input type='hidden' name='nomePersonale' value=$n>";
			 echo"</div>";
			 
			 echo"<div class='prodotti'>";
			 
				echo"<div id=0>";  //ogni prodotto una riga di questa tabella
	echo"<table><tr><td colspan='2'><b>Prodotti:</b></td></tr>";
	echo"<tr><td>ID Prodotto:</td><td><input type='text' name='IDp[]' id='IDp0' onchange='controlloPresenzaID(this.value,0)'></td></tr>";
	echo"<tr><td>Categoria:</td><td> <select name='cat[]' id='cat0'> <option>Scegli...</option><optgroup label='Audio'><option value='1'>Amplificatori</option> <option value='2'>Home cinema</option><option value='3'>Lettori mp3/mp4</option><optgroup label='Desktop e Notebook'><option value='4'>Notebook</option><option value='5'>Pc</option><option value='6'>Pc - accessori</option><optgroup label='Elettrodomestici grandi'><option value='7'>Frigoriferi</option><option value='8'>Lavastoviglie</option><option value='9'>Lavatrici</option><optgroup label='Elettrodomestici piccoli'><option value='10'>Cottura</option><option value='11'>Forni a microonde</option><option value='12'>Macchine da caffè</option><optgroup label='Fotografia'><option value='13'>Reflex</option><option value='14'>Obiettivi</option><option value='15'>Accessori foto/video</option><optgroup label='Giochi'><option value='16'>Console games</option><option value='17'>Controllees</option><option value='18'>Videogames</option><optgroup label='Monitor e periferiche'><option value='20'>Monitor LCD</option><option value='21'>Tastiere e mouse</option><option value='22'>Web-cam</option><optgroup label='Network e Wireless'><option value='23'>Firewall</option><option value='24'>Hub</option><option value='25'>Modem</option><optgroup label='Scansione e stampa'><option value='26'>Copiatrici Digitali</option><option value='27'>Multifunzione ink-jet</option><option value='28'>Scanner</option><optgroup label='Software'><option value='30'>Adobe</option><option value='31'>Corel</option><option value='32'>Nikon</option><optgroup label='Telefonia'><option value='33'>Fax</option><option value='34'>Smartphone</option><option value='35'>Telefonia Fissa</option><optgroup label='Video'><option value='36'>VideoCamere</option><option value='37'>Decoder</option><option value='38'>Videoproiettori</option></select></td></tr>";
	echo"<tr><td>Nome: </td><td><input type='text' name='nome[]' id='nome0'></td></tr>";
	echo"<tr><td>Descrizione:</td><td><textarea name='descrizione[]' rows='5' cols='80' id='descrizione0'></textarea></td></tr>";
	echo"<tr><td>Scheda Tecnica:</td><td><textarea name='schedaTecnica[]' rows='5' cols='80' id='schedaTecnica0'></textarea></td></tr>";
	echo"<tr><td>Prezzo:</td><td><input type='text' name='prezzo[]' id='prezzo0'></td></tr>";
	echo"<tr><td>Immagine:</td><td><input type='file' name='imm[]' id='imm0'></td></tr>";
	echo"<tr><td>Quantita':</td><td><input type='text' name='quantita[]' id='quantita'></td></tr>";
	echo"</table>";

				echo"</div>";
				echo"<div id=1> </div>";
	
				echo"<tr><td colspan='2'><br><input type='button' value='Aggiungi altro Prodotto...' onclick='inserisciRiga()'> <input type='submit' value='Conferma'></td></tr>";
				
			echo"</div>";

			
		echo "</div>";
	}
?>