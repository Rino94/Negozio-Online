<?php
	$id=$_GET['id'];
	//accedo a p_prodotti e per ogni (IDprenotazione == $id) prelevo IDprodotto e lo cerco in m_prodotti aggiungendo a giacenza la quantità.

	
	//Modifico lo stato della prenotazione
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline",$cn);
	$query = "UPDATE prenotazioni SET Stato=1 WHERE IDprenotazione='$id'";
	mysql_query($query,$cn) or die(mysql_error());
	mysql_close($cn);
	
	//accedo a p_prodotti e per ogni (IDprenotazione == $id) prelevo IDprodotto
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query="SELECT * FROM p_prodotti";
	$risultato=mysql_query($query) or die(mysql_error());
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
			$idP=$riga['IDprenotazione'];
			if ($idP==$id) {
				$IDprod=$riga['IDprodotto'];
				$q=$riga['quantita'];

	//e lo cerco in m_prodotti aggiungendo a giacenza la quantità.
	$kk=0;
	$qq=" SELECT IDprodotto,Giacenza FROM m_prodotti";
	$ris=mysql_query($qq) or die(mysql_error()); 
	while(($rig=mysql_fetch_array($ris,MYSQL_ASSOC))&&($kk==0)){
		foreach($rig as $campo => $valore) 
		$IDprodot=$rig['IDprodotto'];	
			if ($IDprodot==$IDprod) {
				$g=$rig['Giacenza'];
				$kk=1;
			}
	} 
				$g=$g+$q;
				$qqq = "UPDATE m_prodotti SET Giacenza=$g WHERE IDprodotto='$IDprodot'";
				mysql_query($qqq,$cn) or die(mysql_error());

			}
	}

mysql_free_result($risultato);
mysql_close($cn);

header ("location: modificaPrenotazione.php?ins=1");	

?>