<?php
	$i=$_GT['i'];
	include("TabellaInserisciPersonle.php");
?>