<head>
<style type="text/css">
@import "../GestionePersonale/Personale.css";
</style>
</head>
<?php
$i=0;
echo "<table><tr class='dispari'><td>ID Prenotazione</td><td>Data Prenotazione</td><td>Fornitore</td><td>Nome Personale</td><td>Stato</td></tr>";

	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM prenotazioni";
	$risultato=mysql_query($query) or die(mysql_error()); 
	while($riga=mysql_fetch_array($risultato,MYSQL_ASSOC)){
		foreach($riga as $campo => $valore) 
		$IDpren=$riga['IDprenotazione'];
		$dp=$riga['DataPrenotazione'];
		$f=$riga['Fornitore'];
		$Npers=$riga['nomePersonale'];
		$s=$riga['Stato'];
		$i=1;
		if ($s==0) $st="effettuata";
		else if ($s==1) $st="consegnata";
		else $st="errore";

/*Controllo ad IDs (ID della sottocategoria) quale sottocategoria appartiene.
	$q=" SELECT * FROM sottocategoria WHERE IDsottocategoria=$IDs";
	$ris=mysql_query($q) or die(mysql_error()); 
	while($rig=mysql_fetch_array($ris,MYSQL_ASSOC)){
		foreach($rig as $campo => $valore) 
		$IDsottoc=$rig['Nome'];
	} 
	mysql_free_result($ris);		
		*/

		echo "<tr class='   pari' id='$IDpren' onclick=\"location.href='TabellaDettagliPrenotazione.php?id=$IDpren&dp=$dp&f=$f&Npers=$Npers&s=$s'\"> <td> $IDpren </td><td> $dp </td><td> $f </td><td> $Npers </td><td> $st </td></tr>";
	}
	mysql_free_result($risultato);
	mysql_close($cn);

	if ($i==0) echo"<p class='no'><b>Nessuna prenotazione disponibile!!!</b></p>";
?>