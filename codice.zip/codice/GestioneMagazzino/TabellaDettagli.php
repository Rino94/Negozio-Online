<?php	
/*
CASO D'USO: selezionaProdotti
1.	Il caso d’uso inizia quando il Capo Magazzino seleziona un singolo prodotto.


*/	
	
	echo "<table>";
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM m_prodotti";
	$risultato=mysql_query($query);
	$k=0;
	while(($riga=mysql_fetch_array($risultato,MYSQL_ASSOC))&&($k==0)){
		foreach($riga as $campo => $valore) 
			$idP=$riga['IDprodotto'];
			if ($idP==$id) {
				$k=1;
				$IDs=$riga['IDs'];
				$n=$riga['Nome'];
				$d=$riga['Descrizione'];
				$st=$riga['Scheda_Tecnica'];
				$p=$riga['Prezzo'];
				$i=$riga['Immagine'];
				$g=$riga['Giacenza'];
	//Controllo ad IDs (ID della sottocategoria) quale sottocategoria appartiene.
	
	$q=" SELECT * FROM sottocategoria WHERE IDsottocategoria=$IDs";
	$ris=mysql_query($q) or die(mysql_error()); 
	while($rig=mysql_fetch_array($ris,MYSQL_ASSOC)){
		foreach($rig as $campo => $valore) 
		$IDsottoc=$rig['Nome'];
	}
/*
CASO D'USO: selezionaProdotti
	2.	Il Sistema mostra i dettagli del prodotto
*/	
				echo"<tr class='dispari'><td><b>ID Prodotto:</b></td><td>$idP</td></tr>";
				echo"<tr class='pari'><td><b>Sottocategoria:</b></td><td>$IDsottoc</td></tr>";
				echo"<tr class='dispari'><td><b>Nome:</b></td><td>$n</td></tr>";
				echo"<tr class='pari'><td><b>Descrizione:</b></td><td>$d</td></tr>";
				echo"<tr class='dispari'><td><b>Scheda Tecnica:</b></td><td>$st</td></tr>";
				echo"<tr class='pari'><td><b>Prezzo:</b></td><td>$p</td></tr>";
				echo"<tr class='dispari'><td><b>Immagine:</b></td><td><img src='immProdotti/$i'></td></tr>";
				echo"<tr class='pari'><td><b>Giacenza:</b></td><td>$g</td></tr>";

			}
	}
/*
CASO D'USO: selezionaProdotti
	3.	Se il Capo Magazzino seleziona “Modifica” <modificaProdotti>
	4.	Se il Capo Magazzino seleziona “Elimina” <eliminaProdotti>
*/	

				echo"<tr><td colspan='2'><center><input type='button' value='Modifica' onclick=\"location.href='modificaProdotto.php?id=$idP&ids=$IDs'\">";
				echo"<input type='button' value='Elimina' onclick=\"location.href='ControlEliminaProdotto.php?IDp=$idP'\"></center></td></tr>";
	echo"</table>";
mysql_free_result($risultato);
mysql_close($cn);
		
?>