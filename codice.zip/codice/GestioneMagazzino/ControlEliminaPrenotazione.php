<?
//Recupero ID del prenotazione e prodotto da cancellare
	$IDprenotazione = $_GET['IDp'];
	
	

$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline",$cn);
$query = "DELETE FROM prenotazioni WHERE IDprenotazione='$IDprenotazione'";
mysql_query($query,$cn) or die("errore");


$query = "DELETE FROM p_prodotti WHERE IDprenotazione='$IDprenotazione'";
mysql_query($query,$cn) or die("errore");


mysql_close($cn);

// notifico l'avvenuta eliminazione
header ("location: eliminaPrenotazione.php?ins=1");

?>