<?php
/*
CASO D'USO: inserisciProdotti
	2.	Il Sistema memorizza i dati appena inseriti.
	3.	Finché si verificano errori durante l’inserimento dei dati
		3.1. Il Sistema visualizza un messaggio che descrive lo scenario.
		3.2. Il Sistema consente all’Amministratore di correggere l’errore.
		3.3. Il capo magazzino modifica tutti o parte dei dati.
		3.4. il capo magazzino avvia la registrazione dei dati, facendo clic sul pulsante “Conferma”.
	4.	Altrimenti:
		4.1. Il Sistema conferma l’avvenuto inserimento.

*/
//Recupero i dati
	$nomePersonale=$_POST['nomePersonale'];;
	$datapren=$_POST['datapren'];
	$fornitore=$_POST['fornitore'];

	$IDp=$_POST['IDp'];
	$cat=$_POST['cat'];
	$nome=$_POST['nome'];
	$descrizione=$_POST['descrizione'];
	$schedaTecnica=$_POST['schedaTecnica'];
	$prezzo=$_POST['prezzo'];
	//caricamento immagine
	$cartella_upload ="immProdotti/";
	$immag=$_FILES['imm']['name'];
	//move_uploaded_file($_FILES["imm"]["tmp_name"], $cartella_upload.$_FILES["imm"]["name"]);
			
	$quantita=$_POST['quantita'];
	$n=count($IDp);
//Accedo al DB e inserisco i dati relativi alla sola prenotazione.
$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline",$cn);
$query = "INSERT INTO prenotazioni (DataPrenotazione,Fornitore,nomePersonale,Stato)  VALUES ('$datapren','$fornitore','$nomePersonale',0)"; 
//Stato =0 => Prenotazione effettuata

mysql_query($query,$cn) or die (mysql_error());
$uID=mysql_insert_id(); //recupero ultimo ID inserito
mysql_close($cn);

for($i=0;$i<$n;$i++) {
//Per ogni prodotto:
	$ip=$IDp[$i];
	$c=$cat[$i];
	$nom=$nome[$i];
	$d=$descrizione[$i];
	$d=addslashes($d);
	$st=$schedaTecnica[$i];
	$p=$prezzo[$i];
	$im=$immag[$i];
	move_uploaded_file($_FILES["imm"]["tmp_name"][$i], $cartella_upload.$_FILES["imm"]["name"][$i]);
	$q=$quantita[$i];

//-Verifico se ID è già presente nel DB
	$k=0;
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline");
	$query=" SELECT * FROM m_prodotti";
	$risultato=mysql_query($query);
		while(($riga=mysql_fetch_array($risultato,MYSQL_ASSOC))&&($k==0)){
		foreach($riga as $campo => $valore)
		if (($riga["IDprodotto"] == $ip)) {
			$k=1;		
		}
	}
	mysql_free_result($risultato);
	mysql_close($cn);
//-Se è già presente allora aggiorno i dati (perchè avrei potuto fare delle modifiche)
	if($k==1) {
		$cn = mysql_connect("localhost","root");
		mysql_select_db("negozionline",$cn);
		$query = "UPDATE m_prodotti SET Nome='$nom',IDs='$c',Descrizione='$d',Scheda_Tecnica='$st',Prezzo='$p',Immagine='$im' WHERE IDprodotto='$ip'";
		mysql_query($query,$cn) or die(mysql_error());
		mysql_close($cn);
	}
//se non è presente allora aggiundo i dati al db
	else {
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline",$cn);
	$query = "INSERT INTO m_prodotti (IDprodotto,IDs,Nome,Descrizione,Scheda_Tecnica,Prezzo,Immagine)  VALUES ('$ip','$c','$nom','$d','$st','$p','$im')";
	mysql_query($query,$cn)  or die(mysql_error());
	mysql_close($cn);
	}
//-Inserisco la corrispondenza in p_prodotti
	$cn = mysql_connect("localhost","root");
	mysql_select_db("negozionline",$cn);
	$query = "INSERT INTO p_prodotti (IDprodotto,IDprenotazione,Quantita)  VALUES ('$ip','$uID','$q')";
	mysql_query($query,$cn) or die(mysql_error());
	mysql_close($cn);
	
//Torno alla pagina di inserimento e notifico l'avvenuto inserimento
header ("location: InserisciProdotti.php?ins=1");	
}
?>