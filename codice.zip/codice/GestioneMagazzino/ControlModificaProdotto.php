<?php
//Recupero i dati
	$IDp=$_POST['IDp'];
	$IDs=$_POST['IDs'];
	$n=$_POST['n'];
	$d=$_POST['d'];
	$d=addslashes($d);
	$st=$_POST['st'];
	$p=$_POST['p'];
	$g=$_POST['g'];

//Accedo al DB e modifico i dati.
$cn = mysql_connect("localhost","root");
mysql_select_db("negozionline",$cn);
	//se è stato selezionato un file:
	if(trim($_FILES["i"]["name"]) != '') {
		//carico immagine immagine ed effettuo query che aggiorna anche il file
		$cartella_upload ="immProdotti/";
		$im=$_FILES['i']['name'];
		move_uploaded_file($_FILES["i"]["tmp_name"], $cartella_upload.$_FILES["i"]["name"]);
		$query = "UPDATE m_prodotti SET Nome='$n',IDs='$IDs',Descrizione='$d',Scheda_Tecnica='$st',Prezzo='$p',Giacenza='$g',Immagine='$im' WHERE IDprodotto='$IDp'";
	}
	//altrimenti effettuo query senza aggiornare file
	else {
		$query = "UPDATE m_prodotti SET Nome='$n',IDs='$IDs',Descrizione='$d',Scheda_Tecnica='$st',Prezzo='$p',Giacenza='$g' WHERE IDprodotto='$IDp'";

	}
mysql_query($query,$cn) or die(mysql_error());
mysql_close($cn);

//Torno alla pagina di inserimento e notifico l'avvenuto inserimento
header ("location: modificaProdotto.php?ins=1");	

	?>