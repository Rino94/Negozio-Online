<?php session_start(); ?>

<html>
<!--
CASO D'USO: elencaProdotti
	1.	Il caso d’uso inizia quando il Capo Magazzino è stato autenticato dal sistema e viene reindirizzato alla sua area d’accesso.	
-->
<head>
<title> Gestione Personale </title>

<style type="text/css">
@import "../GestionePersonale/Personale.css";
@import "GestioneMagazzino.css";
</style>
<script type="text/javascript" src="FunzioniJS.js"> </script>
</head>

<body>
<?php
	if(!isset($_SESSION['nik']))	
		echo "Connessione fallita!!!";
	else {
		$n=$_SESSION['nik'];
		echo "<div class='contenitore'>";
			 include("../intestazionePersonale.php");
			echo "<div class='home'> <a href='GestioneMagazzino.php'>-Home </a> </div>";
			echo "<div class='inserisci'> <a href='InserisciProdotti.php'>-Inserisci Prodotti </a> </div>";
/*
CASO D'USO: elencaProdotti
	2.	Include(ricercaProdotti)

CASO D'USO: ricercaProdotti	
1.	Il Sistema mostra un elenco di prodotti(o prenotazioni) unitamente ai criteri di filtraggio.
2.	Se il Capo Magazzino inserisce i criteri di ricerca:
2.1 Il Sistema ricerca i dati che soddisfano i criteri di ricerca specificati.
2.2 Se il Sistema trova uno o più prodotti o prenotazioni che soddisfano i criteri:
       2.2.1. Il Sistema mostra un elenco di prodotti (o prenotazioni).
       2.2.2. Finché ci sono altri prodotti
                   2.2.2.1. Il Sistema consente di visualizzare il successivo elenco.
*/
			
			 echo "<div class='sel'>Cerca: <select onchange='ControlSel(this.value)'>";
				echo"<option> in base a: </option>";
				echo"<option value='0'> ID Articolo </option>";
				echo"<option value='1'> Nome Articolo </option>";
				echo"<option value='2'> Categoria </option>";
				echo"<option value='4'> Giacenza </option>";
				echo"<option value='3'> Prenotazioni </option>";
				
			 echo"</select>";
			 echo "</div>";
			 
			 echo "<div class='att'   id='att'> </div>";
			 echo "<div class='cerca' id='cerca'> </div>";
			 
			 echo "<div class='tab' id='tab'> </div>";

			
		echo "</div>";
	}
?>