<?php session_start(); ?>

<html>
<head>
<title> Gestione Personale </title>

<style type="text/css">
@import "Personale.css";
</style>

</head>

<body>
<?php
	if(!isset($_SESSION['nik']))	
		echo "Connessione fallita!!!";
	else {
		$n=$_SESSION['nik'];
		echo "<div class='contenitore'>";
			 include("../intestazionePersonale.php");
			
		echo "</div>";
	}
?>