-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generato il: Feb 12, 2014 alle 01:21
-- Versione del server: 5.6.11
-- Versione PHP: 5.5.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `negozionline`
--
CREATE DATABASE IF NOT EXISTS `negozionline` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `negozionline`;

-- --------------------------------------------------------

--
-- Struttura della tabella `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `IDcategoria` int(5) NOT NULL,
  `Nome` char(40) NOT NULL,
  PRIMARY KEY (`IDcategoria`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `categorie`
--

INSERT INTO `categorie` (`IDcategoria`, `Nome`) VALUES
(1, 'Audio'),
(2, 'Destop e Noteboo'),
(3, 'Elettrodomestici Grandi'),
(4, 'Elettrodomestici Piccoli'),
(5, 'Fotografia'),
(6, 'Giochi'),
(7, 'Monitor e Periferiche'),
(8, 'Network e Wireless'),
(9, 'Scansione e Stampa'),
(10, 'Software'),
(11, 'Telefonia'),
(12, 'Video');

-- --------------------------------------------------------

--
-- Struttura della tabella `dettaglipersonale`
--

CREATE TABLE IF NOT EXISTS `dettaglipersonale` (
  `Nome` char(20) NOT NULL,
  `Cognome` char(20) NOT NULL,
  `DataNascita` char(10) NOT NULL,
  `Ruolo` char(20) NOT NULL,
  `IDruolo` int(11) NOT NULL,
  `Username` char(20) NOT NULL,
  `Password` char(20) NOT NULL,
  `IDpersonale` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`IDpersonale`),
  KEY `IDruolo` (`IDruolo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dump dei dati per la tabella `dettaglipersonale`
--

INSERT INTO `dettaglipersonale` (`Nome`, `Cognome`, `DataNascita`, `Ruolo`, `IDruolo`, `Username`, `Password`, `IDpersonale`) VALUES
('Renata', 'Giordano', '19/08/1988', 'CapoMagazzino', 2, 'renatagio', 'renatagio', 1),
('Giuseppe', 'Alvino', '12/05/1987', 'CapoMagazzino', 2, 'giuseppealv', 'Giuseppe', 4),
('Angela', 'DePasquale', '01/01/1989', 'CapoMagazzino', 2, 'Angela', 'Angela', 5),
('Gaetano', 'Memoli', '07/07/1999', 'Magazziniere', 3, 'gaetano', 'gaetano', 6),
('Annarita', 'Galano', '22/01/1990', 'Magazziniere', 3, 'annarita', 'annarita', 7),
('Miriam', 'Granatello', '11/11/1922', 'Magazziniere', 3, 'miriam', 'miriam', 8),
('Rosario', 'Ronchi', '21/12/1967', 'Magazziniere', 3, 'rosario', 'rosario', 11),
('Michele', 'Ronchi', '24.05.1956', 'CapoMagazzino', 2, 'cristinaron', 'cristinaron', 14),
('Katia', 'Tardio', '04.05.1990', 'Magazziniere', 3, 'katiatar', 'katiatar', 19),
('Luca', 'Melucci', '23.10.1989', 'Aministratore', 1, 'lucamel', 'lucamel', 20),
('Stefano', 'DeFeo', '12.04.1989', 'Magazziniere', 3, 'stefanodef', 'stefanodef', 21),
('Simone', 'Villano', '12.12.1985', 'CapoMagazzino', 2, 'simonevil', 'simonevil', 22);

-- --------------------------------------------------------

--
-- Struttura della tabella `m_prodotti`
--

CREATE TABLE IF NOT EXISTS `m_prodotti` (
  `IDprodotto` bigint(20) NOT NULL AUTO_INCREMENT,
  `IDs` int(10) NOT NULL,
  `Nome` char(20) NOT NULL,
  `Descrizione` longtext NOT NULL,
  `Scheda_Tecnica` text NOT NULL,
  `Prezzo` double NOT NULL,
  `Immagine` char(40) NOT NULL,
  `Giacenza` int(10) NOT NULL,
  PRIMARY KEY (`IDprodotto`),
  KEY `IDs` (`IDs`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30313 ;

--
-- Dump dei dati per la tabella `m_prodotti`
--

INSERT INTO `m_prodotti` (`IDprodotto`, `IDs`, `Nome`, `Descrizione`, `Scheda_Tecnica`, `Prezzo`, `Immagine`, `Giacenza`) VALUES
(855, 10, 'LUNCH TIME', 'PORTAVIVANDE ELETTRICO CON SISTEMA RISCALDANTE A TEMPERATURA COSTANTE\r\n\r\nLunch Time &#65533; un elegante e compatto portavivande elettrico che puoi portare ovunque. In pochi minuti ti permette di riscaldare cibi preparati in casa o piatti gi&#65533; pronti senza renderli asciutti o stopposi.\r\n\r\nSemplice da usare non necessita di acqua per il riscaldamento delle pietanze.\r\n\r\nDotato di comodo contenitore interno a due vani che ti consente di consumare direttamente i cibi.\r\n\r\nSemplice da pulire, i due contenitori estraibili si possono lavare anche in lavastoviglie.\r\n\r\nMolto sicuro grazie alla resistenza autoregolante che mantiene costante la temperatura evitando di bruciare i cibi. Pratico vano porta posata.\r\n\r\nLunch Time: un unico prodotto per trasportare, riscaldare e consumare i cibi che preferisci.\r\n\r\nCONTENUTO CONFEZIONE:\r\n1 Portavivande elettrico\r\n1 Contenitore a 2 scomparti\r\n1 Contenitore con coperchio\r\n1 Cucchiaio\r\n1 Libretto istruzioni', 'Tipologia: scalda vivande; Potenza: 40 w; Colore Primario: bianco;', 19, '', 12),
(1323, 10, 'WAFFLE MAKER CLASSIC', 'WAFFLE MAKER CLASSIC\r\n\r\nin acciaio inossidabile\r\nideale per preparare waffles per la colazione da abbinare al caffè\r\npiastre antiaderenti\r\nspia di funzionamento e indicatore pronta cottura', 'Tipologia: waffle maker; Potenza: 1.000 w; Colore Primario: grigio;', 23, 'PRC_08_134943_132391_Big.jpg', 6),
(3180, 4, 'Nikon D3100', 'Include la fotocamera D3100 e l''obiettivo AF-S DX18-105mm f/3.5-5.6G!\r\n\r\nFotocamera SLR in formato DX straordinariamente semplice da usare con sensore di immagine CMOS a 14,2 megapixel, modo guida, EXPEED 2, sistema di autofocus a 11 punti estremamente preciso e D-Movie full HD. È dotata di corpo leggero e caratteristiche ergonomiche superiori. L''ampio monitor LCD ad alta risoluzione da 3" semplifica la visualizzazione delle informazioni essenziali relative alla fotocamera e rende piacevole la visione e la modifica di foto e filmati.\r\n\r\nIl modo guida mostra come scattare immagini eccellenti in tutta semplicità, sia che si tratti di un ritratto di famiglia, sia che serva rapidità di scatto per catturare i primi passi di un bambino.\r\nD-Movie consente di registrare filmati Full HD e riprendere l''azione con eccellente qualità di giorno o di notte.\r\nIl modulo di elaborazione delle immagini EXPEED 2 avanzato consente di esaltare al massimo le prestazioni del sensore per ottenere immagini incredibilmente chiare con colori vivaci.\r\nElevata sensibilità alla luce ISO (100-3200) , estendibile fino a 12800: presenta un''impostazione ISO Auto ed è manualmente estendibile fino a ISO 12800 utilizzando l''impostazione  Hi2. Consente tempi di posa più rapidi per ridurre il rischio di immagini mosse quando si riprendono soggetti in rapido movimento o si scattano fotografie in condizioni di luce debole.\r\nLive View con selezione automatica scene: agevola la composizione delle immagini utilizzando il monitor LCD. La Selezione automatica scene sceglie il modo più adatto alla scena e al soggetto da fotografare e il modo AF permanente (AF-F) mantiene i soggetti a fuoco senza dover premere il pulsante di scatto.\r\nD-Lighting attivo consente di conservare automaticamente i particolari in condizioni di alte-luci oppure ombre, creando fotografie con un contrasto naturale.\r\nPicture Control consente di impostare l''aspetto e l''atmosfera delle immagini. È possibile scegliere sei diverse impostazioni: Standard, Saturo, Neutro, Monocromatico, Ritratto e Panorama.', 'Megapixel Effettivi: 14,200; Obiettivi Inclusi: 1; Tipo Di Flash: pop-up; Tipo Di Attacco: nikon af dx / af-s dx; Dimensioni : 3 inches; Stabilizzatore : no; Riproduzione Hd: sì;', 580, '1CA_FJ_129128_5170B017_Big.jpg', 23),
(5170, 13, 'Canon 600D', 'Con una risoluzione di 18 megapixel, leader della categoria, un design intuitivo e la possibilità di utilizzare la gamma completa di obiettivi e accessori EOS, EOS 600D vi consente di esprimere al massimo il vostro estro fotografico.\r\n\r\nSensore CMOS APS-C da 18 megapixel\r\nIl sensore CMOS APS-C da 18 megapixel cattura immagini nitide e ricche di dettagli. Grazie all''elevata risoluzione, è possibile ottenere stampe di grandi dimensioni e avere la libertà di ritagliare le immagini per creare nuove composizioni.\r\n\r\nSensibilità ISO 100-6400\r\nLa gamma ISO di 100-6400, espandibile fino a ISO 12.800, consente di eseguire scatti di alta qualità a mano libera anche in condizioni di scarsa luminosità, senza utilizzare il flash. \r\n\r\nElaborazione delle immagini a 14 bit\r\nIl cuore di Canon EOS 600D è un processore di immagine DIGIC 4 a 14 bit che assicura un''eccezionale riproduzione dei colori, una gradazione dei toni uniforme e un controllo superiore del rumore.\r\n\r\nModalità Scena Smart Auto\r\nLa modalità Scena Smart Auto analizza ogni scena in dettagli e seleziona le impostazioni appropriate per ogni circostanza, lasciandovi liberi di concentrarvi sull''elemento più importante: la foto da scattare.', 'Megapixel Effettivi: 18; Obiettivi Inclusi: 0; Tipo Di Flash: pop-up; Tipo Di Attacco: canon ef / ef-s; Dimensioni : 3 inches; Stabilizzatore : no; Riproduzione Hd: sì;', 450, '1CA_FJ_129128_5170B017_Big.jpg', 23),
(7708, 18, 'Fifa 11', 'FIFA 11 reinventa il realismo dei giocatori, con e senza palla, per ogni posizione sul campo. Il nuovissimo sistema Personality+ riflette le abilità individuali nel gioco, permettendo una chiara differenziazione per ogni calciatore. \r\n\r\nGrazie a Personality+, le abilità in campo di ogni giocatore sono replicate realisticamente nel gioco, creando personalità individuali. I giocatori saranno distinti tra loro grazie a un sofisticato database che valuta le capacità di ogni calciatore in 36 attributi e 57 caratteristiche, compilato da 1.700 scout in tutto il mondo. Kakà del Real Madrid fornirà passaggi creativi e precisi, Andres Iniesta del Barcellona dribblerà gli avversari con i suoi repentini cambi di direzione e il controllo di palla impeccabile, Wayne Rooney del Manchester United terrà lontani i marcatori e colpirà dalla distanza grazie al suo ritmo indiavolato e i migliori difensori, come Giorgio Chiellini della Juventus, anticiperanno, prevederanno e reagiranno agli attaccanti avversari per riconquistare palla. ', 'Genere: sport; Piattaforma: pc; Editore: electronic arts; Lingua Manuale: italiano; Lingua Gioco: versione italiana; Day One: 2010-10-01; Numero Giocatori Max (No Online): 2;', 7, 'EAR_GB_191433_EAI07708036_Big.jpg', 0),
(9099, 4, 'F200CA', '<b>ASUS VivoBook F200CA</b><br>\r\n\r\nNB ultramobile 11,6&#65533; con processore dual-core Intel Celeron 1007U , 2GB di memoria RAM , 500GB di storage e sistema operativo Windows 8. Dal design raffinato, colore nero, sottile e leggero (1,24kg) Nuovo ASUS VivoBook F200CA rappresenta lo stato dell&#65533;arte della tecnologia Ultramobile. Grazie alla feature Instant-On,  il notebook si riavvia in 2 secondi, il display da 11.6 pollici esalta l&#65533;esperienza d&#65533;uso di Windows 8 mentre la tecnologia Asus SonicMaster garantisce una qualit&#65533; Audio insospettabile in un 11 pollici. In dotazione modulo WiFi 802.11n, Bluetooth 4.0, una porta USB 3.0 e due USB 2.0, Ethernet, HDMI e VGA  Assicurazione Kasko 1 anno; Garanzia Zero Bright Dot per la durata di 30 giorni; 32GB di Asus WebStorage Gratuito per 3 anni', '<b>Tecnologia:</b> celeron; <b>Ram Installata:</b> 2 gb; <b>Dimensioni:</b> 11,600 "; <b>Dimensione Tot. Supporti:</b> 500 gb; <b>Touch Screen:</b> no; <b>S.O.:</b> windows 8; <b>Versione S.O.:</b> home;', 299, 'ASK_NO_231498_F200CA-KX216H_Big.jpg', 12),
(30312, 4, 'CHROMEBOOK', 'Il Nuovo Samsung Chromebook\r\n\r\nSamsung Chromebook è per tutti!\r\n\r\nSamsung Chromebook è un nuovo notebook che ti aiuta a gestire le tue attività quotidiane più facilmente e velocemente. Si accende in pochi secondi e ti permette di scegliere tra le numerose app di Google così potrai giocare, lavorare in ogni momento!\r\n\r\nScegli Samsung Chromebook con s.o. Google Chrome!\r\n\r\nHDD: 16GB e.MMC iNAND™ Embedded Flash Drive\r\n\r\nScegli la tecnologia vincente di Samsung!', 'Tecnologia: exynos; Ram Installata: 2 gb; Dimensioni: 11,600 "; Dimensione Tot. Supporti: 16 gb; Touch Screen: no; S.O.: google chrome; Versione S.O.: chrome;', 285, '', 5);

-- --------------------------------------------------------

--
-- Struttura della tabella `prenotazioni`
--

CREATE TABLE IF NOT EXISTS `prenotazioni` (
  `IDprenotazione` bigint(20) NOT NULL AUTO_INCREMENT,
  `DataPrenotazione` char(10) NOT NULL,
  `Fornitore` char(20) NOT NULL,
  `nomePersonale` char(20) NOT NULL,
  `Stato` char(20) NOT NULL,
  PRIMARY KEY (`IDprenotazione`),
  KEY `IDpersonale` (`nomePersonale`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dump dei dati per la tabella `prenotazioni`
--

INSERT INTO `prenotazioni` (`IDprenotazione`, `DataPrenotazione`, `Fornitore`, `nomePersonale`, `Stato`) VALUES
(33, '10.02.2014', 'oikka.it', 'renatagio', '1'),
(38, '11.02.2014', 'Melucci&CO', 'renatagio', '1'),
(39, '12.02.2014', 'Melucci&CO', 'renatagio', '0');

-- --------------------------------------------------------

--
-- Struttura della tabella `p_prodotti`
--

CREATE TABLE IF NOT EXISTS `p_prodotti` (
  `IDprodotto` int(20) NOT NULL,
  `IDprenotazione` int(20) NOT NULL,
  `quantita` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `p_prodotti`
--

INSERT INTO `p_prodotti` (`IDprodotto`, `IDprenotazione`, `quantita`) VALUES
(99, 28, 10),
(444, 29, 12),
(444, 30, 12),
(444, 31, 12),
(444, 32, 12),
(9099, 33, 12),
(30312, 33, 5),
(9099, 34, 12),
(99999, 35, 12),
(12345, 36, 10),
(7708, 37, 9),
(855, 38, 12),
(1323, 38, 6),
(5170, 38, 23),
(3180, 38, 23),
(855, 39, 7);

-- --------------------------------------------------------

--
-- Struttura della tabella `ruolipersonale`
--

CREATE TABLE IF NOT EXISTS `ruolipersonale` (
  `IDruolo` int(11) NOT NULL,
  `link` char(40) NOT NULL,
  PRIMARY KEY (`IDruolo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `ruolipersonale`
--

INSERT INTO `ruolipersonale` (`IDruolo`, `link`) VALUES
(1, 'GestionePersonale/GestionePersonale'),
(2, 'GestioneMagazzino/GestioneMagazzino'),
(3, 'GestionePrenotazione/GestionePrenotazion');

-- --------------------------------------------------------

--
-- Struttura della tabella `sottocategoria`
--

CREATE TABLE IF NOT EXISTS `sottocategoria` (
  `IDsottocategoria` int(10) NOT NULL,
  `IDc` int(10) NOT NULL,
  `Nome` char(20) NOT NULL,
  PRIMARY KEY (`IDsottocategoria`),
  KEY `IDc` (`IDc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dump dei dati per la tabella `sottocategoria`
--

INSERT INTO `sottocategoria` (`IDsottocategoria`, `IDc`, `Nome`) VALUES
(1, 1, 'Amplificatori'),
(2, 1, 'Home cinema'),
(3, 1, 'Lettori mp3/mp4'),
(4, 2, 'Notebook'),
(5, 2, 'Pc'),
(6, 2, 'Pc - accessori'),
(7, 3, 'Frigoriferi'),
(8, 3, 'Lavastoviglie'),
(9, 3, 'Lavatrici'),
(10, 4, 'Cottura'),
(11, 4, 'Forni a microonde'),
(12, 4, 'Macchine da caffè'),
(13, 5, 'Reflex'),
(14, 5, 'Obiettivi'),
(15, 5, 'Accessori foto/video'),
(16, 6, 'Consoles games'),
(17, 6, 'Controllers'),
(18, 6, 'Videogames'),
(20, 7, 'Monitor lcd'),
(21, 7, 'Tastiere e mouse'),
(22, 7, 'Web-cam'),
(23, 8, 'Firewall'),
(24, 8, 'Hub'),
(25, 8, 'Modem'),
(26, 9, 'Copiatrici digitali'),
(27, 9, 'Multifunzione ink-je'),
(28, 9, 'Scanner'),
(30, 10, 'Adobe'),
(31, 10, 'Corel'),
(32, 10, 'Nikon'),
(33, 11, 'Fax'),
(34, 11, 'Smartphone'),
(35, 11, 'Telefonia fissa'),
(36, 12, 'Videocamere'),
(37, 12, 'Decoder'),
(38, 12, 'Videoproiettori');

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `dettaglipersonale`
--
ALTER TABLE `dettaglipersonale`
  ADD CONSTRAINT `dettaglipersonale_ibfk_1` FOREIGN KEY (`IDruolo`) REFERENCES `ruolipersonale` (`IDruolo`);

--
-- Limiti per la tabella `m_prodotti`
--
ALTER TABLE `m_prodotti`
  ADD CONSTRAINT `m_prodotti_ibfk_2` FOREIGN KEY (`IDs`) REFERENCES `sottocategoria` (`IDsottocategoria`);

--
-- Limiti per la tabella `sottocategoria`
--
ALTER TABLE `sottocategoria`
  ADD CONSTRAINT `sottocategoria_ibfk_1` FOREIGN KEY (`IDc`) REFERENCES `categorie` (`IDcategoria`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
