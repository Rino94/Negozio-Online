<?php
session_start();
$_SESSION['nik'] = array();
session_destroy();
header('location: IndexPersonale.php');
exit();
?>