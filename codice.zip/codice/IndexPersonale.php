<?php
	/* In questa pagina impostiamo il form per l'inserimento delle credenziali da parte dello staff (amministratore,capo magazzino,magazziniere).
	*/
	//Recupero K che se settato e se == 1 allora precedentemente c'è stato un errore nel Login
if (isset($_GET['k']))
	$err=1;
else
	$err=0;
?>
<html>
<head> <title> NegoziOnline </title>
<style type="text/css">
@import "IndexPersonale.css";
</style>
</head>
<body>
<form method="post" action="loginPersonale.php">
<div class="esterno">
	<div class="tabella">
	<table><tr><td colspan="2"> <h2><center> Login </h2></td></tr>
	<tr><td>Username:</td><td><input type="text" name="username"></td></tr>
	<tr><td>Password:</td><td><input type="password" name="password"></td></tr>
	<tr><td colspan="2"><center><input type="submit" value="Login"></td></tr>
	
	</div>
	<div id="mess">
	<?php
	if ($err==1) echo "<tr><td colspan='2' class='err'><center><b> Login o Password errati!! </td></tr>";
	?>
	</div>
	</table>
</div>
</body>
</html>